import { create } from 'zustand'
import type { MoodEntry, MoodLevel } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'
import { todayStr } from '@/utils/date'

interface MoodState {
  entries: MoodEntry[]
  upsertToday: (input: Omit<MoodEntry, 'id' | 'createdAt' | 'date'>) => MoodEntry
  update: (id: string, patch: Partial<MoodEntry>) => void
  remove: (id: string) => void
}

export const useMoodStore = create<MoodState>((set, get) => ({
  entries: Storage.get<MoodEntry[]>(StorageKeys.Mood) ?? [],
  upsertToday: (input) => {
    const today = todayStr()
    const existing = get().entries.find((m) => m.date === today)
    const now = new Date().toISOString()
    if (existing) {
      const updated: MoodEntry = { ...existing, ...input }
      save(get, get().entries.map((m) => (m.id === existing.id ? updated : m)))
      return updated
    }
    const created: MoodEntry = { id: genId(), createdAt: now, date: today, ...input }
    save(get, [created, ...get().entries])
    return created
  },
  update: (id, patch) => save(get, get().entries.map((m) => (m.id === id ? { ...m, ...patch } : m))),
  remove: (id) => save(get, get().entries.filter((m) => m.id !== id))
}))

function save(get: () => MoodState, next: MoodEntry[]) {
  Storage.set(StorageKeys.Mood, next)
  useMoodStore.setState({ entries: next })
}

export const MoodEmojiMap: Record<MoodLevel, { emoji: string; label: string; color: string }> = {
  1: { emoji: '😣', label: '糟糕', color: '#ef4444' },
  2: { emoji: '😕', label: '低落', color: '#f59e0b' },
  3: { emoji: '😐', label: '一般', color: '#94a3b8' },
  4: { emoji: '🙂', label: '还不错', color: '#0ea5e9' },
  5: { emoji: '🤩', label: '极佳', color: '#22c55e' }
}
