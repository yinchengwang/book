import { create } from 'zustand'
import type { FitnessRecord } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface FitnessState {
  records: FitnessRecord[]
  add: (input: Omit<FitnessRecord, 'id' | 'createdAt'>) => FitnessRecord
  update: (id: string, patch: Partial<FitnessRecord>) => void
  remove: (id: string) => void
}

export const useFitnessStore = create<FitnessState>((set, get) => ({
  records: Storage.get<FitnessRecord[]>(StorageKeys.Fitness) ?? [],
  add: (input) => {
    const item: FitnessRecord = { id: genId(), createdAt: new Date().toISOString(), ...input }
    save(get, [item, ...get().records])
    return item
  },
  update: (id, patch) => save(get, get().records.map((r) => (r.id === id ? { ...r, ...patch } : r))),
  remove: (id) => save(get, get().records.filter((r) => r.id !== id))
}))

function save(get: () => FitnessState, next: FitnessRecord[]) {
  Storage.set(StorageKeys.Fitness, next)
  useFitnessStore.setState({ records: next })
}
