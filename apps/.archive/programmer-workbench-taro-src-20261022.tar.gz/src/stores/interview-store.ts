import { create } from 'zustand'
import type { InterviewQuestion } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface InterviewState {
  questions: InterviewQuestion[]
  add: (input: Omit<InterviewQuestion, 'id' | 'createdAt' | 'starred' | 'reviewCount'>) => InterviewQuestion
  update: (id: string, patch: Partial<InterviewQuestion>) => void
  remove: (id: string) => void
  toggleStar: (id: string) => void
  markReviewed: (id: string) => void
}

export const useInterviewStore = create<InterviewState>((set, get) => ({
  questions: Storage.get<InterviewQuestion[]>(StorageKeys.Interview) ?? [],
  add: (input) => {
    const item: InterviewQuestion = { id: genId(), createdAt: new Date().toISOString(), starred: false, reviewCount: 0, ...input }
    save(get, [item, ...get().questions])
    return item
  },
  update: (id, patch) => save(get, get().questions.map((q) => (q.id === id ? { ...q, ...patch } : q))),
  remove: (id) => save(get, get().questions.filter((q) => q.id !== id)),
  toggleStar: (id) => save(get, get().questions.map((q) => (q.id === id ? { ...q, starred: !q.starred } : q))),
  markReviewed: (id) =>
    save(get, get().questions.map((q) =>
      q.id === id ? { ...q, reviewCount: q.reviewCount + 1, lastReviewed: new Date().toISOString() } : q
    ))
}))

function save(get: () => InterviewState, next: InterviewQuestion[]) {
  Storage.set(StorageKeys.Interview, next)
  useInterviewStore.setState({ questions: next })
}
