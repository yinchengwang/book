import { create } from 'zustand'
import type { Insight } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface InsightsState {
  insights: Insight[]
  add: (input: { content: string; tags?: string[] }) => Insight
  update: (id: string, patch: Partial<Insight>) => void
  remove: (id: string) => void
  togglePin: (id: string) => void
  archive: (id: string, v: boolean) => void
}

export const useInsightsStore = create<InsightsState>((set, get) => ({
  insights: Storage.get<Insight[]>(StorageKeys.Insights) ?? [],
  add: ({ content, tags = [] }) => {
    const item: Insight = { id: genId(), content, tags, pinned: false, archived: false, createdAt: new Date().toISOString() }
    save(get, [item, ...get().insights])
    return item
  },
  update: (id, patch) => save(get, get().insights.map((i) => (i.id === id ? { ...i, ...patch } : i))),
  remove: (id) => save(get, get().insights.filter((i) => i.id !== id)),
  togglePin: (id) => save(get, get().insights.map((i) => (i.id === id ? { ...i, pinned: !i.pinned } : i))),
  archive: (id, v) => save(get, get().insights.map((i) => (i.id === id ? { ...i, archived: v } : i)))
}))

function save(get: () => InsightsState, next: Insight[]) {
  Storage.set(StorageKeys.Insights, next)
  useInsightsStore.setState({ insights: next })
}
