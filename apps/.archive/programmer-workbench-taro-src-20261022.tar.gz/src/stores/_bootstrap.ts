import { Storage } from '@/utils/storage'
import { useTodosStore } from './todos-store'
import { useTechNotesStore } from './tech-notes-store'
import { useSnippetsStore } from './snippets-store'
import { useInterviewStore } from './interview-store'
import { useResourcesStore } from './resources-store'
import { useReadingStore } from './reading-store'
import { useFitnessStore } from './fitness-store'
import { useMoodStore } from './mood-store'
import { useScheduleStore } from './schedule-store'
import { useProjectsStore } from './projects-store'
import { useInsightsStore } from './insights-store'

const SEEDED_KEY = '__seeded__'

export function initAllStores() {
  if (Storage.get<boolean>(SEEDED_KEY)) return
  const today = new Date().toISOString()

  if (!useTodosStore.getState().todos.length) {
    const s = useTodosStore.getState()
    s.add({ title: '完成 DevBench 工作台 v1 看板布局', priority: 'high', category: 'work', dueDate: today })
    s.add({ title: '阅读《系统设计面试》前 4 章', priority: 'med', category: 'learning' })
    s.add({ title: '晨跑 5 公里', priority: 'low', category: 'life' })
  }

  if (!useTechNotesStore.getState().notes.length) {
    const s = useTechNotesStore.getState()
    s.add({
      title: 'React Hooks 最佳实践',
      category: 'frontend',
      content: '# 核心要点\n- 单一职责,每个 useState 只负责一个状态\n- 副作用放 useEffect,记得写 cleanup\n- 自定义 Hook 抽离可复用逻辑(以 use 开头)\n- 配合 memo / useMemo 减少重渲染',
      tags: ['react', 'hooks'], pinned: true
    })
    s.add({
      title: 'PostgreSQL 索引原理速记',
      category: 'database',
      content: '- B-Tree 索引适合等值与范围查询\n- 复合索引遵循最左前缀\n- 部分索引:\n```sql\nCREATE INDEX idx_orders_pending ON orders(id) WHERE status = \'pending\';\n```',
      tags: ['postgres', 'index'], pinned: false
    })
  }

  if (!useSnippetsStore.getState().snippets.length) {
    const s = useSnippetsStore.getState()
    s.add({
      title: '防抖(debounce)',
      language: 'typescript',
      description: '通用防抖函数',
      tags: ['utility', 'fn'],
      code: `export function debounce<T extends (...a: any[]) => any>(fn: T, ms = 300) {\n  let t: any\n  return (...args: Parameters<T>) => {\n    clearTimeout(t)\n    t = setTimeout(() => fn(...args), ms)\n  }\n}`
    })
    s.add({
      title: 'Python 异步上下文',
      language: 'python',
      description: 'asyncio 异步上下文管理器',
      tags: ['python', 'async'],
      code: `import asyncio, contextlib\n\n@contextlib.asynccontextmanager\nasync def timer(label):\n    start = asyncio.get_event_loop().time()\n    try:\n        yield\n    finally:\n        print(label, asyncio.get_event_loop().time() - start)`
    })
  }

  if (!useInterviewStore.getState().questions.length) {
    const s = useInterviewStore.getState()
    s.add({
      question: '什么是 React 中的虚拟 DOM?它的优势是什么?',
      answer: '虚拟 DOM 是 React 内部维护的一棵 JS 对象树,描述真实 DOM 的结构。\n\n优势:\n1. 跨平台渲染(浏览器、Native、小程序)\n2. 通过 Diff 算法最小化 DOM 操作\n3. 声明式编程模型,UI = f(state)',
      category: 'frontend', difficulty: 'med'
    })
    s.add({
      question: 'TCP 三次握手的过程?为什么是三次?',
      answer: '三次握手:SYN -> SYN+ACK -> ACK。\n\n目的:双方同步序列号并确认收发能力。\n两次无法确认 B 是否收到 SYN,四次浪费。',
      category: 'backend', difficulty: 'med'
    })
  }

  if (!useResourcesStore.getState().resources.length) {
    const s = useResourcesStore.getState()
    s.add({
      title: 'Designing Data-Intensive Applications',
      type: 'book', category: 'backend',
      url: 'https://dataintensive.net', stars: 5,
      note: '系统设计与存储引擎必读,反复刷'
    })
    s.add({
      title: 'Taro 官方文档',
      type: 'doc', category: 'mobile',
      url: 'https://docs.taro.zone', stars: 4
    })
  }

  if (!useReadingStore.getState().list.length) {
    const s = useReadingStore.getState()
    s.add({ title: '代码整洁之道', author: 'Robert C. Martin', totalPages: 450, status: 'reading', rating: 5 })
    s.add({ title: '深入理解计算机系统', author: 'Bryant', totalPages: 800, status: 'wishlist' })
  }

  if (!useFitnessStore.getState().records.length) {
    useFitnessStore.getState().add({
      date: new Date().toISOString().slice(0, 10),
      type: 'cardio', name: '晨跑', durationMin: 30, calories: 280
    })
  }

  if (!useMoodStore.getState().entries.length) {
    useMoodStore.getState().upsertToday({
      level: 4, emoji: '🙂', tags: ['work', 'code'],
      note: '今天修了几个 bug,心情不错。'
    })
  }

  if (!useScheduleStore.getState().events.length) {
    const t = new Date(Date.now() + 86400_000)
    t.setHours(10, 0, 0, 0)
    useScheduleStore.getState().add({ title: '团队周会', startAt: t.toISOString(), location: '线上 - 腾讯会议' })
  }

  if (!useProjectsStore.getState().projects.length) {
    useProjectsStore.getState().add({
      name: 'DevBench · 程序员工作台',
      description: '为开发者量身定制的个人工作台,集成技术学习、生活记录、工具集与作品展示。',
      techStack: ['Taro 3.6', 'React 18', 'TypeScript', 'Zustand'],
      status: 'active', stars: 5,
      highlights: ['离线优先,数据本地化', '7 大板块一站式管理', '内置 10+ 开发常用工具']
    })
  }

  if (!useInsightsStore.getState().insights.length) {
    const s = useInsightsStore.getState()
    s.add({ content: '本地优先的架构让小程序的体验稳定,先 OL 再 Sync。', tags: ['arch'] })
    s.add({ content: 'TypeScript 的 discriminated union 在表单状态机里非常顺手。', tags: ['ts', 'tip'] })
  }

  Storage.set(SEEDED_KEY, true)
}

export function clearAllLocalData() {
  Storage.clearAll()
  useTodosStore.setState({ todos: [] })
  useTechNotesStore.setState({ notes: [] })
  useSnippetsStore.setState({ snippets: [] })
  useInterviewStore.setState({ questions: [] })
  useResourcesStore.setState({ resources: [] })
  useReadingStore.setState({ list: [] })
  useFitnessStore.setState({ records: [] })
  useMoodStore.setState({ entries: [] })
  useScheduleStore.setState({ events: [] })
  useProjectsStore.setState({ projects: [] })
  useInsightsStore.setState({ insights: [] })
  Storage.remove(SEEDED_KEY)
}
