import { create } from 'zustand'
import type { TechResource } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface ResourcesState {
  resources: TechResource[]
  add: (input: Omit<TechResource, 'id' | 'createdAt' | 'archived'>) => TechResource
  update: (id: string, patch: Partial<TechResource>) => void
  remove: (id: string) => void
  toggleArchive: (id: string) => void
}

export const useResourcesStore = create<ResourcesState>((set, get) => ({
  resources: Storage.get<TechResource[]>(StorageKeys.Resources) ?? [],
  add: (input) => {
    const item: TechResource = { id: genId(), createdAt: new Date().toISOString(), archived: false, ...input }
    save(get, [item, ...get().resources])
    return item
  },
  update: (id, patch) => save(get, get().resources.map((r) => (r.id === id ? { ...r, ...patch } : r))),
  remove: (id) => save(get, get().resources.filter((r) => r.id !== id)),
  toggleArchive: (id) => save(get, get().resources.map((r) => (r.id === id ? { ...r, archived: !r.archived } : r)))
}))

function save(get: () => ResourcesState, next: TechResource[]) {
  Storage.set(StorageKeys.Resources, next)
  useResourcesStore.setState({ resources: next })
}
