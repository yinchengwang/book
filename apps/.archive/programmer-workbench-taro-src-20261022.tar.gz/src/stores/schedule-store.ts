import { create } from 'zustand'
import type { ScheduleEvent } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface ScheduleState {
  events: ScheduleEvent[]
  add: (input: Omit<ScheduleEvent, 'id' | 'createdAt' | 'done'>) => ScheduleEvent
  update: (id: string, patch: Partial<ScheduleEvent>) => void
  remove: (id: string) => void
  toggleDone: (id: string) => void
}

export const useScheduleStore = create<ScheduleState>((set, get) => ({
  events: Storage.get<ScheduleEvent[]>(StorageKeys.Schedule) ?? [],
  add: (input) => {
    const item: ScheduleEvent = { id: genId(), createdAt: new Date().toISOString(), done: false, ...input }
    save(get, [item, ...get().events])
    return item
  },
  update: (id, patch) => save(get, get().events.map((e) => (e.id === id ? { ...e, ...patch } : e))),
  remove: (id) => save(get, get().events.filter((e) => e.id !== id)),
  toggleDone: (id) => save(get, get().events.map((e) => (e.id === id ? { ...e, done: !e.done } : e)))
}))

function save(get: () => ScheduleState, next: ScheduleEvent[]) {
  Storage.set(StorageKeys.Schedule, next)
  useScheduleStore.setState({ events: next })
}
