import { create } from 'zustand'
import type { CodeSnippet, SnippetLanguage } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface SnippetsState {
  snippets: CodeSnippet[]
  add: (input: Omit<CodeSnippet, 'id' | 'createdAt' | 'favorite'>) => CodeSnippet
  update: (id: string, patch: Partial<CodeSnippet>) => void
  remove: (id: string) => void
  toggleFav: (id: string) => void
}

export const useSnippetsStore = create<SnippetsState>((set, get) => ({
  snippets: Storage.get<CodeSnippet[]>(StorageKeys.Snippets) ?? [],
  add: (input) => {
    const item: CodeSnippet = { id: genId(), createdAt: new Date().toISOString(), favorite: false, ...input }
    save(get, [item, ...get().snippets])
    return item
  },
  update: (id, patch) => save(get, get().snippets.map((s) => (s.id === id ? { ...s, ...patch } : s))),
  remove: (id) => save(get, get().snippets.filter((s) => s.id !== id)),
  toggleFav: (id) => save(get, get().snippets.map((s) => (s.id === id ? { ...s, favorite: !s.favorite } : s)))
}))

function save(get: () => SnippetsState, next: CodeSnippet[]) {
  Storage.set(StorageKeys.Snippets, next)
  useSnippetsStore.setState({ snippets: next })
}

export const LanguageMap: Record<SnippetLanguage, { label: string; color: string }> = {
  javascript: { label: 'JS', color: '#f7df1e' },
  typescript: { label: 'TS', color: '#3178c6' },
  python:     { label: 'PY', color: '#3572a5' },
  go:         { label: 'GO', color: '#00add8' },
  rust:       { label: 'RS', color: '#dea584' },
  java:       { label: 'JV', color: '#b07219' },
  cpp:        { label: 'C++',color: '#f34b7d' },
  sql:        { label: 'SQL',color: '#e38c00' },
  shell:      { label: 'SH', color: '#89e051' },
  other:      { label: '···',color: '#94a3b8' }
}
