import { create } from 'zustand'
import type { TodoItem, TodoPriority } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface TodosState {
  todos: TodoItem[]
  add: (input: Omit<TodoItem, 'id' | 'createdAt' | 'done'>) => TodoItem
  toggle: (id: string) => void
  update: (id: string, patch: Partial<TodoItem>) => void
  remove: (id: string) => void
  clearDone: () => void
}

export const useTodosStore = create<TodosState>((set, get) => ({
  todos: Storage.get<TodoItem[]>(StorageKeys.Todos) ?? [],

  add: (input) => {
    const item: TodoItem = { id: genId(), createdAt: new Date().toISOString(), done: false, ...input }
    persist(get, [item, ...get().todos])
    return item
  },
  toggle: (id) => persist(get, get().todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t))),
  update: (id, patch) => persist(get, get().todos.map((t) => (t.id === id ? { ...t, ...patch } : t))),
  remove: (id) => persist(get, get().todos.filter((t) => t.id !== id)),
  clearDone: () => persist(get, get().todos.filter((t) => !t.done))
}))

function persist(get: () => TodosState, next: TodoItem[]) {
  Storage.set(StorageKeys.Todos, next)
  useTodosStore.setState({ todos: next })
}

export const PriorityMap: Record<TodoPriority, { label: string; color: string }> = {
  low: { label: '低', color: '#22c55e' },
  med: { label: '中', color: '#f59e0b' },
  high: { label: '高', color: '#ef4444' }
}
