import { create } from 'zustand'
import type { Project } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface ProjectsState {
  projects: Project[]
  add: (input: Omit<Project, 'id' | 'createdAt'>) => Project
  update: (id: string, patch: Partial<Project>) => void
  remove: (id: string) => void
}

export const useProjectsStore = create<ProjectsState>((set, get) => ({
  projects: Storage.get<Project[]>(StorageKeys.Projects) ?? [],
  add: (input) => {
    const item: Project = { id: genId(), createdAt: new Date().toISOString(), ...input }
    save(get, [item, ...get().projects])
    return item
  },
  update: (id, patch) => save(get, get().projects.map((p) => (p.id === id ? { ...p, ...patch } : p))),
  remove: (id) => save(get, get().projects.filter((p) => p.id !== id))
}))

function save(get: () => ProjectsState, next: Project[]) {
  Storage.set(StorageKeys.Projects, next)
  useProjectsStore.setState({ projects: next })
}
