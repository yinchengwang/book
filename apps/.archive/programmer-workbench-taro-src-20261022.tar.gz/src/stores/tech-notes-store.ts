import { create } from 'zustand'
import type { TechNote, TechCategory } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface TechNotesState {
  notes: TechNote[]
  add: (input: Omit<TechNote, 'id' | 'createdAt' | 'updatedAt'>) => TechNote
  update: (id: string, patch: Partial<TechNote>) => void
  remove: (id: string) => void
  togglePin: (id: string) => void
}

export const useTechNotesStore = create<TechNotesState>((set, get) => ({
  notes: Storage.get<TechNote[]>(StorageKeys.TechNotes) ?? [],
  add: (input) => {
    const now = new Date().toISOString()
    const item: TechNote = { id: genId(), createdAt: now, updatedAt: now, ...input }
    save(get, [item, ...get().notes])
    return item
  },
  update: (id, patch) =>
    save(get, get().notes.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: new Date().toISOString() } : n))),
  remove: (id) => save(get, get().notes.filter((n) => n.id !== id)),
  togglePin: (id) => save(get, get().notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)))
}))

function save(get: () => TechNotesState, next: TechNote[]) {
  Storage.set(StorageKeys.TechNotes, next)
  useTechNotesStore.setState({ notes: next })
}

export const TechCategoryMap: Record<TechCategory, { label: string; color: string; emoji: string }> = {
  frontend: { label: '前端', color: '#0ea5e9', emoji: '🎨' },
  backend:  { label: '后端', color: '#22c55e', emoji: '⚙️' },
  mobile:   { label: '移动端', color: '#f59e0b', emoji: '📱' },
  devops:   { label: 'DevOps', color: '#8b5cf6', emoji: '🚀' },
  ai:       { label: 'AI/ML', color: '#ec4899', emoji: '🤖' },
  database: { label: '数据库', color: '#10b981', emoji: '💾' },
  other:    { label: '其他', color: '#64748b', emoji: '📦' }
}
