import { create } from 'zustand'
import { Storage, StorageKeys } from '@/utils/storage'
import type { Settings, ThemeMode, UserProfile } from '@/types'

const DEFAULT: Settings = {
  theme: 'auto',
  primaryColor: '#0ea5e9',
  enableHaptics: true,
  enableDailyReminder: true,
  reminderTime: '09:00',
  profile: {
    nickname: 'DevBencHer',
    role: '全栈工程师',
    bio: '对代码有洁癖的工程师,偶尔写写文字记录灵感。',
    motto: 'Write less, ship more. ✨',
    yearsOfExperience: 3
  },
  schemaVersion: 1
}

interface SettingsState extends Settings {
  setTheme: (t: ThemeMode) => void
  setPrimaryColor: (c: string) => void
  setEnableHaptics: (v: boolean) => void
  setEnableDailyReminder: (v: boolean) => void
  setReminderTime: (t: string) => void
  updateProfile: (p: Partial<UserProfile>) => void
  resetSettings: () => void
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  ...DEFAULT,
  ...(Storage.get<Settings>(StorageKeys.Settings) ?? {}),

  setTheme: (theme) => persistAndSet({ theme }),
  setPrimaryColor: (primaryColor) => persistAndSet({ primaryColor }),
  setEnableHaptics: (enableHaptics) => persistAndSet({ enableHaptics }),
  setEnableDailyReminder: (enableDailyReminder) => persistAndSet({ enableDailyReminder }),
  setReminderTime: (reminderTime) => persistAndSet({ reminderTime }),
  updateProfile: (profile) => persistAndSet({ profile: { ...get().profile, ...profile } }),
  resetSettings: () => { Storage.remove(StorageKeys.Settings); set(DEFAULT) }
}))

function persistAndSet(patch: Partial<Settings>) {
  set(patch)
  const s = useSettingsStore.getState()
  const snapshot: Settings = {
    theme: s.theme, primaryColor: s.primaryColor,
    enableHaptics: s.enableHaptics, enableDailyReminder: s.enableDailyReminder,
    reminderTime: s.reminderTime, profile: s.profile, schemaVersion: s.schemaVersion
  }
  Storage.set(StorageKeys.Settings, snapshot)
}

function set(patch: Partial<Settings>) { useSettingsStore.setState(patch as any) }
