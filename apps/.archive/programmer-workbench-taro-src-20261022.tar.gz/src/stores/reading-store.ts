import { create } from 'zustand'
import type { ReadingItem } from '@/types'
import { Storage, StorageKeys } from '@/utils/storage'
import { genId } from '@/utils/id'

interface ReadingState {
  list: ReadingItem[]
  add: (input: Omit<ReadingItem, 'id' | 'createdAt' | 'currentPage'>) => ReadingItem
  update: (id: string, patch: Partial<ReadingItem>) => void
  remove: (id: string) => void
  setPage: (id: string, page: number) => void
  setStatus: (id: string, status: ReadingItem['status']) => void
}

export const useReadingStore = create<ReadingState>((set, get) => ({
  list: Storage.get<ReadingItem[]>(StorageKeys.Reading) ?? [],
  add: (input) => {
    const item: ReadingItem = { id: genId(), createdAt: new Date().toISOString(), currentPage: 0, ...input }
    save(get, [item, ...get().list])
    return item
  },
  update: (id, patch) => save(get, get().list.map((r) => (r.id === id ? { ...r, ...patch } : r))),
  remove: (id) => save(get, get().list.filter((r) => r.id !== id)),
  setPage: (id, page) => save(get, get().list.map((r) => {
    if (r.id !== id) return r
    const safe = Math.max(0, Math.min(page, r.totalPages ?? page))
    return { ...r, currentPage: safe }
  })),
  setStatus: (id, status) => {
    const now = new Date().toISOString()
    save(get, get().list.map((r) => {
      if (r.id !== id) return r
      const patch: Partial<ReadingItem> = { status }
      if (status === 'reading' && !r.startedAt) patch.startedAt = now
      if (status === 'finished') patch.finishedAt = now
      return { ...r, ...patch }
    }))
  }
}))

function save(get: () => ReadingState, next: ReadingItem[]) {
  Storage.set(StorageKeys.Reading, next)
  useReadingStore.setState({ list: next })
}
