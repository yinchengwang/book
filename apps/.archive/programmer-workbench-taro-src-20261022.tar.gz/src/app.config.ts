/**
 * 应用全局配置 / 路由 + tabBar
 *
 * 🔧 修复(2026-10-19):tabBar 不再依赖任何 PNG 图标。
 *    微信原生 tabBar 在不指定 iconPath / selectedIconPath 时,仅展示纯文字。
 *    我们走文字 tabBar 路线——零资源依赖,克隆即跑。
 *
 *    如果后续想换成有图标的样式,有两种推荐做法:
 *    1. 准备 5 组 81x81 PNG,放进 src/assets/icons/,然后在这里补上 iconPath 字段
 *    2. 用 Taro 自定义 tabBar 方案 (`custom: true`),用前端组件绘制 SVG —— 见 README
 */
export default defineAppConfig({
  pages: [
    'pages/dashboard/index',
    'pages/tech/index',
    'pages/life/index',
    'pages/tools/index',
    'pages/profile/index',
    'pages/tech/notes/index',
    'pages/tech/notes/detail',
    'pages/tech/snippets/index',
    'pages/tech/snippets/detail',
    'pages/tech/interview/index',
    'pages/tech/interview/detail',
    'pages/tech/resources/index',
    'pages/life/reading/index',
    'pages/life/fitness/index',
    'pages/life/mood/index',
    'pages/life/schedule/index',
    'pages/projects/index',
    'pages/insights/index'
  ],
  window: {
    navigationBarTitleText: 'DevBench',
    navigationBarBackgroundColor: '#0f172a',
    navigationBarTextStyle: 'white',
    backgroundColor: '#0f172a',
    backgroundTextStyle: 'dark'
  },
  tabBar: {
    color: '#94a3b8',
    selectedColor: '#38bdf8',
    backgroundColor: '#0f172a',
    borderStyle: 'black',
    list: [
      { pagePath: 'pages/dashboard/index', text: '工作台' },
      { pagePath: 'pages/tech/index',      text: '技术栈' },
      { pagePath: 'pages/life/index',      text: '生活' },
      { pagePath: 'pages/tools/index',     text: '工具箱' },
      { pagePath: 'pages/profile/index',   text: '我的' }
    ]
  },
  style: 'v2',
  sitemapLocation: 'sitemap.json',
  lazyCodeLoading: 'requiredComponents'
})
