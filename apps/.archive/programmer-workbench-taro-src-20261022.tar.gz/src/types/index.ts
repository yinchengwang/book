export type ID = string
export type ISODate = string
export type ThemeMode = 'light' | 'dark' | 'auto'

// 工作台 / 待办
export type TodoPriority = 'low' | 'med' | 'high'
export interface TodoItem {
  id: ID; title: string; done: boolean; priority: TodoPriority
  dueDate?: ISODate; category?: string; createdAt: ISODate
}

// 技术栈
export type TechCategory = 'frontend' | 'backend' | 'mobile' | 'devops' | 'ai' | 'database' | 'other'
export interface TechNote {
  id: ID; title: string; content: string; category: TechCategory
  tags: string[]; pinned: boolean; createdAt: ISODate; updatedAt: ISODate
}
export type SnippetLanguage =
  | 'javascript' | 'typescript' | 'python' | 'go' | 'rust' | 'java' | 'cpp' | 'sql' | 'shell' | 'other'
export interface CodeSnippet {
  id: ID; title: string; language: SnippetLanguage; code: string
  description?: string; tags: string[]; favorite: boolean; createdAt: ISODate
}
export interface InterviewQuestion {
  id: ID; question: string; answer: string; category: TechCategory
  difficulty: 'easy' | 'med' | 'hard'; starred: boolean
  reviewCount: number; lastReviewed?: ISODate; createdAt: ISODate
}
export type ResourceType = 'article' | 'video' | 'book' | 'repo' | 'tool' | 'doc'
export interface TechResource {
  id: ID; title: string; url?: string; type: ResourceType; category: TechCategory
  note?: string; stars: number; archived: boolean; createdAt: ISODate
}

// 个人生活
export interface ReadingItem {
  id: ID; title: string; author?: string; totalPages?: number
  currentPage: number; status: 'wishlist' | 'reading' | 'finished' | 'paused'
  rating?: number; notes?: string; cover?: string
  startedAt?: ISODate; finishedAt?: ISODate; createdAt: ISODate
}
export type FitnessType = 'cardio' | 'strength' | 'flexibility' | 'sports' | 'other'
export interface FitnessRecord {
  id: ID; date: string; type: FitnessType; name: string
  durationMin: number; calories?: number; notes?: string; createdAt: ISODate
}
export type MoodLevel = 1 | 2 | 3 | 4 | 5
export interface MoodEntry {
  id: ID; date: string; level: MoodLevel; emoji: string
  tags: string[]; note?: string; createdAt: ISODate
}
export interface ScheduleEvent {
  id: ID; title: string; startAt: ISODate; endAt?: ISODate
  location?: string; note?: string; reminder?: boolean; done: boolean; createdAt: ISODate
}

// 项目
export type ProjectStatus = 'active' | 'archived' | 'wip'
export interface Project {
  id: ID; name: string; description: string; techStack: string[]
  status: ProjectStatus; stars: number; repoUrl?: string; demoUrl?: string
  highlights: string[]; startDate?: ISODate; endDate?: ISODate; createdAt: ISODate
}

// 闪念
export interface Insight {
  id: ID; content: string; tags: string[]
  pinned: boolean; archived: boolean; createdAt: ISODate
}

// 设置
export interface UserProfile {
  nickname: string; avatar?: string; role: string
  bio?: string; motto?: string; yearsOfExperience?: number
}
export interface Settings {
  theme: ThemeMode; primaryColor: string
  enableHaptics: boolean; enableDailyReminder: boolean
  reminderTime: string; profile: UserProfile; schemaVersion: number
}
