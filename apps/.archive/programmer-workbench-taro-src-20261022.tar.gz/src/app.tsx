import { useEffect } from 'react'
import Taro from '@tarojs/taro'
import { useSettingsStore } from '@/stores/settings-store'
import { initAllStores } from '@/stores/_bootstrap'
import './app.scss'

function App({ children }: { children?: React.ReactNode }) {
  const theme = useSettingsStore((s) => s.theme)

  useEffect(() => {
    initAllStores()
    Taro.getSystemInfo({}).then((res) => {
      const sysTheme = res.theme ?? 'light'
      const finalTheme = theme === 'auto' ? sysTheme : theme
      if (typeof document !== 'undefined') {
        document.documentElement.setAttribute('data-theme', finalTheme)
      }
    })
    Taro.setStorageSync('__systemInfo__', Taro.getSystemInfoSync())
  }, [])

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', theme === 'auto' ? '' : theme)
    }
  }, [theme])

  return children
}

export default App
