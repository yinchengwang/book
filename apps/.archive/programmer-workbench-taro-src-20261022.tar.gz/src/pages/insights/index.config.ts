export default definePageConfig({ navigationBarTitleText: '闪念', enablePullDownRefresh: true })
