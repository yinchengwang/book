import { View, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useInsightsStore } from '@/stores/insights-store'
import { Empty } from '@/components/common/Empty'
import { formatRelative } from '@/utils/date'
import { showPrompt } from '@/utils/dialog'

const QUOTES = [
  '灵感稍纵即逝,现在写下来',
  '记录即思考',
  '最小行动,马上落笔',
  '今天的一行字,可能救明天的你',
  '让想法变成可追溯的足迹'
]

export default function InsightsPage() {
  const insights = useInsightsStore((s) => s.insights)
  const add = useInsightsStore((s) => s.add)
  const update = useInsightsStore((s) => s.update)
  const remove = useInsightsStore((s) => s.remove)
  const togglePin = useInsightsStore((s) => s.togglePin)
  const archive = useInsightsStore((s) => s.archive)
  const [input, setInput] = useState('')
  const [tagInput, setTagInput] = useState('')
  const quote = useMemo(() => QUOTES[Math.floor(Math.random() * QUOTES.length)], [])
  const visible = useMemo(() => insights.filter((i) => !i.archived), [insights])
  const archived = useMemo(() => insights.filter((i) => i.archived), [insights])

  const submit = () => {
    const text = input.trim()
    if (!text) return
    const tags = tagInput.split(/[,，\s]+/).map((t) => t.trim().replace(/^#/, '')).filter(Boolean)
    add({ content: text, tags })
    setInput(''); setTagInput('')
    Taro.showToast({ title: '已保存', icon: 'success' })
  }
  const onLongPress = (id: string, pinned: boolean, isArchived: boolean) => {
    Taro.showActionSheet({
      itemList: [pinned ? '取消置顶' : '置顶', isArchived ? '取消归档' : '归档', '编辑', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) togglePin(id)
        else if (r.tapIndex === 1) archive(id, !isArchived)
        else if (r.tapIndex === 2) {
          const item = insights.find((i) => i.id === id)
          if (!item) return
          showPrompt({
            title: '编辑闪念',
            content: item.content,
            placeholderText: '闪念内容'
          }).then((text) => {
            if (text && text.trim()) update(id, { content: text.trim() })
          })
        } else if (r.tapIndex === 3) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ borderRadius: '32rpx', padding: '32rpx 24rpx', background: 'linear-gradient(135deg, #f59e0b 0%, #ec4899 100%)', color: 'white', marginBottom: '24rpx', boxShadow: 'var(--shadow-md)' }}>
        <Text style={{ fontSize: '40rpx', fontWeight: 700 }}>💡 闪念</Text>
        <View style={{ fontSize: '26rpx', marginTop: '16rpx', lineHeight: 1.5, opacity: 0.95 }}>"{quote}"</View>
      </View>

      <View style={{ display: 'flex', gap: '16rpx', marginBottom: '16rpx' }}>
        <Input value={input} onInput={(e) => setInput((e.detail as any).value)} onConfirm={submit}
          placeholder='此刻的灵感,是什么?'
          style={{ flex: 1, height: '88rpx', padding: '0 24rpx', borderRadius: '44rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <View style={{ width: '88rpx', height: '88rpx', borderRadius: '50%', background: 'var(--accent)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '40rpx' }} onClick={submit}>+</View>
      </View>
      <Input value={tagInput} onInput={(e) => setTagInput((e.detail as any).value)}
        placeholder='标签 (逗号分隔,可选)'
        style={{ width: '100%', height: '64rpx', padding: '0 24rpx', borderRadius: '32rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', fontSize: '24rpx', marginBottom: '24rpx', color: 'var(--text-primary)' }} />

      {visible.length === 0 && <Empty icon='💭' title='还没有闪念' desc='把一闪而过的念头留下来,说不定哪天用得上。' />}
      {visible.sort((a, b) =>
        a.pinned !== b.pinned ? (a.pinned ? -1 : 1) : b.createdAt.localeCompare(a.createdAt)
      ).map((i) => (
        <View key={i.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)', position: 'relative' }} onLongPress={() => onLongPress(i.id, i.pinned, false)}>
          <View style={{ position: 'absolute', right: '24rpx', top: '24rpx', fontSize: '32rpx', color: i.pinned ? 'var(--warning)' : 'var(--text-muted)' }} onClick={() => togglePin(i.id)}>
            {i.pinned ? '📌' : '📍'}
          </View>
          <Text style={{ fontSize: '28rpx', lineHeight: 1.6, color: 'var(--text-primary)', paddingRight: '50rpx', wordBreak: 'break-word' }}>{i.content}</Text>
          <View style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '8rpx', marginTop: '16rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
            {i.tags.length > 0 && (
              <View style={{ display: 'flex', flexWrap: 'wrap', gap: '4rpx' }}>
                {i.tags.map((t) => (
                  <View key={t} style={{ padding: '2rpx 12rpx', background: 'var(--accent-soft)', color: 'var(--accent)', borderRadius: '999rpx', fontSize: '22rpx' }}>
                    <Text>#{t}</Text>
                  </View>
                ))}
              </View>
            )}
            <Text style={{ marginLeft: 'auto' }}>{formatRelative(i.createdAt)}</Text>
          </View>
        </View>
      ))}

      {archived.length > 0 && (
        <View style={{ marginTop: '32rpx' }}>
          <View className='section-title'>
            <View className='section-title__main'>
              <View className='section-title__bar' style={{ background: 'var(--text-muted)' }} />
              <Text className='section-title__text'>已归档 ({archived.length})</Text>
            </View>
          </View>
          {archived.slice(0, 5).map((i) => (
            <View key={i.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', opacity: 0.6 }} onLongPress={() => onLongPress(i.id, i.pinned, true)}>
              <Text style={{ fontSize: '28rpx', lineHeight: 1.6 }}>{i.content}</Text>
              <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)', marginTop: '8rpx' }}>{formatRelative(i.createdAt)}</Text>
            </View>
          ))}
        </View>
      )}
    </View>
  )
}
