import { View, Text, Input, Textarea, RichText } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useEffect, useState } from 'react'
import { useTechNotesStore, TechCategoryMap } from '@/stores/tech-notes-store'
import { Header } from '@/components/common/Header'
import { md2html } from '@/utils/codetools'
import type { TechCategory } from '@/types'

export default function NoteDetail() {
  const id = Taro.getCurrentInstance().router?.params?.id
  const isEdit = Boolean(id)
  const notes = useTechNotesStore((s) => s.notes)
  const add = useTechNotesStore((s) => s.add)
  const update = useTechNotesStore((s) => s.update)
  const remove = useTechNotesStore((s) => s.remove)
  const existing = isEdit ? notes.find((n) => n.id === id) : undefined

  const [title, setTitle] = useState(existing?.title ?? '')
  const [content, setContent] = useState(existing?.content ?? '# 新笔记\n\n在这里书写你的想法...')
  const [category, setCategory] = useState<TechCategory>(existing?.category ?? 'frontend')
  const [tagsText, setTagsText] = useState(existing?.tags.join(', ') ?? '')
  const [preview, setPreview] = useState(false)

  useEffect(() => {
    Taro.setNavigationBarTitle({ title: isEdit ? '编辑笔记' : '新建笔记' })
  }, [isEdit])

  const save = () => {
    const t = title.trim(), c = content.trim()
    if (!t) return Taro.showToast({ title: '请输入标题', icon: 'none' })
    if (!c) return Taro.showToast({ title: '请输入内容', icon: 'none' })
    const tags = tagsText.split(/[,，\s]+/).map((x) => x.trim().replace(/^#/, '')).filter(Boolean)
    if (isEdit && existing) update(existing.id, { title: t, content: c, category, tags })
    else add({ title: t, content: c, category, tags, pinned: false })
    Taro.showToast({ title: '已保存', icon: 'success' })
    setTimeout(() => Taro.navigateBack(), 400)
  }
  const onDelete = () => {
    if (!isEdit || !existing) return
    Taro.showModal({
      title: '删除笔记?', content: '将无法恢复', success: (m) => {
        if (m.confirm) { remove(existing.id); Taro.navigateBack() }
      }
    })
  }
  const html = preview ? md2html(content) : ''

  return (
    <View style={{ minHeight: '100vh', padding: '24rpx', background: 'var(--bg-primary)' }}>
      <Header title={isEdit ? '编辑笔记' : '新建笔记'} showBack
        rightSlot={<Text style={{ color: 'var(--brand)' }} onClick={save}>保存</Text>} />
      <Input
        placeholder='标题' value={title} onInput={(e) => setTitle((e.detail as any).value)}
        style={{ width: '100%', fontSize: '40rpx', fontWeight: 700, color: 'var(--text-primary)', padding: '24rpx 0', borderBottom: '1rpx solid var(--border)' }}
      />
      <View style={{ margin: '24rpx 0' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>分类</Text>
        <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginTop: '8rpx' }}>
          {Object.entries(TechCategoryMap).map(([key, info]) => (
            <View key={key}
              className={`tag-row__item${category === key ? ' tag-row__item--active' : ''}`}
              onClick={() => setCategory(key as TechCategory)}
              style={category === key ? { background: info.color, borderColor: info.color } : undefined}>
              {info.emoji} {info.label}
            </View>
          ))}
        </View>
      </View>
      <View style={{ margin: '24rpx 0' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>标签 (逗号分隔)</Text>
        <Input placeholder='例如: react, hooks' value={tagsText} onInput={(e) => setTagsText((e.detail as any).value)}
          style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '26rpx', marginTop: '8rpx', color: 'var(--text-primary)' }}
        />
      </View>
      <View style={{ margin: '24rpx 0' }}>
        <View style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>内容 (Markdown)</Text>
          <Text style={{ color: 'var(--brand)' }} onClick={() => setPreview(!preview)}>{preview ? '编辑' : '预览'}</Text>
        </View>
        {preview ? (
          <View style={{ marginTop: '16rpx', padding: '24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', color: 'var(--text-primary)', fontSize: '26rpx', lineHeight: 1.7 }}>
            <RichText nodes={html || ''} />
          </View>
        ) : (
          <Textarea value={content} onInput={(e) => setContent((e.detail as any).value)} autoHeight
            style={{ width: '100%', minHeight: '360rpx', padding: '24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '28rpx', lineHeight: 1.6, marginTop: '8rpx', color: 'var(--text-primary)' }}
          />
        )}
      </View>
      <View style={{ display: 'flex', gap: '16rpx', marginTop: '24rpx' }}>
        <View className='detail__btn detail__btn--ghost' onClick={() => Taro.navigateBack()}>取消</View>
        <View className='detail__btn detail__btn--primary' onClick={save}>保存</View>
      </View>
      {isEdit && (
        <View className='detail__btn detail__btn--ghost' style={{ marginTop: '24rpx', color: 'var(--danger)' }} onClick={onDelete}>删除笔记</View>
      )}
    </View>
  )
}
