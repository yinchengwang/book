import { View, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useTechNotesStore, TechCategoryMap } from '@/stores/tech-notes-store'
import { Tag } from '@/components/common/Tag'
import { Empty } from '@/components/common/Empty'
import { formatRelative } from '@/utils/date'
import type { TechCategory } from '@/types'

type FilterKey = 'all' | TechCategory

export default function NotesList() {
  const notes = useTechNotesStore((s) => s.notes)
  const togglePin = useTechNotesStore((s) => s.togglePin)
  const remove = useTechNotesStore((s) => s.remove)
  const [kw, setKw] = useState('')
  const [filter, setFilter] = useState<FilterKey>('all')

  const filtered = useMemo(() => {
    let list = notes
    if (filter !== 'all') list = list.filter((n) => n.category === filter)
    const k = kw.trim().toLowerCase()
    if (k) {
      list = list.filter((n) =>
        n.title.toLowerCase().includes(k) ||
        n.content.toLowerCase().includes(k) ||
        n.tags.some((t) => t.toLowerCase().includes(k))
      )
    }
    return [...list].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    })
  }, [notes, kw, filter])

  const onCreate = () => Taro.navigateTo({ url: '/pages/tech/notes/detail' })
  const onOpen = (id: string) => Taro.navigateTo({ url: `/pages/tech/notes/detail?id=${id}` })
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['置顶/取消置顶', '编辑', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) togglePin(id)
        else if (r.tapIndex === 1) onOpen(id)
        else if (r.tapIndex === 2) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <Input
        placeholder='搜索标题、内容或标签' value={kw}
        onInput={(e) => setKw((e.detail as any).value)}
        style={{ height: '72rpx', padding: '0 24rpx', borderRadius: '36rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', fontSize: '26rpx', color: 'var(--text-primary)', marginBottom: '24rpx' }}
      />
      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginBottom: '24rpx' }}>
        <View className={`tag-row__item${filter === 'all' ? ' tag-row__item--active' : ''}`} onClick={() => setFilter('all')}>全部</View>
        {Object.entries(TechCategoryMap).map(([key, info]) => (
          <View key={key}
            className={`tag-row__item${filter === key ? ' tag-row__item--active' : ''}`}
            onClick={() => setFilter(key as TechCategory)}
            style={filter === key ? { background: info.color, borderColor: info.color } : undefined}>
            {info.emoji} {info.label}
          </View>
        ))}
      </View>
      {filtered.length === 0 && <Empty icon='📝' title='还没有笔记' desc='点击 + 写下一条笔记' actionText='新建笔记' onAction={onCreate} />}
      {filtered.map((n) => (
        <View key={n.id} className='note-card' onClick={() => onOpen(n.id)} onLongPress={() => onLongPress(n.id)}>
          <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16rpx' }}>
            <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)', flex: 1 }}>{n.title}</Text>
            {n.pinned && <Text style={{ marginLeft: '16rpx', color: 'var(--warning)', fontSize: '28rpx' }}>📌</Text>}
          </View>
          <Text className='line-clamp-2' style={{ fontSize: '24rpx', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '16rpx' }}>
            {n.content.replace(/[#*`>\-]/g, '').trim().slice(0, 80)}
          </Text>
          <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '22rpx', color: 'var(--text-muted)' }}>
            <View style={{ display: 'flex', flexWrap: 'wrap', gap: '4rpx' }}>
              <Tag color={TechCategoryMap[n.category].color} bg={`${TechCategoryMap[n.category].color}20`}>{TechCategoryMap[n.category].label}</Tag>
              {n.tags.slice(0, 3).map((t) => <Tag key={t}>#{t}</Tag>)}
            </View>
            <Text>{formatRelative(n.updatedAt)}</Text>
          </View>
        </View>
      ))}
      <View className='fab' onClick={onCreate}>+</View>
      <style dangerouslySetInnerHTML={{ __html: `
        .note-card { background: var(--bg-secondary); border-radius: 24rpx; padding: 24rpx; margin-bottom: 16rpx; box-shadow: var(--shadow-sm); }
      ` }} />
    </View>
  )
}
