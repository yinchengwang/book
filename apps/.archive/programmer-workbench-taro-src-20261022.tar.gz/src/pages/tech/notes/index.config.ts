export default definePageConfig({ navigationBarTitleText: '技术笔记', enablePullDownRefresh: true })
