export default definePageConfig({ navigationBarTitleText: '技术栈', enablePullDownRefresh: true })
