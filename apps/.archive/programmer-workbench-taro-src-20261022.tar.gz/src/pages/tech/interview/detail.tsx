import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useEffect, useState } from 'react'
import { useInterviewStore } from '@/stores/interview-store'
import { TechCategoryMap } from '@/stores/tech-notes-store'
import { Header } from '@/components/common/Header'
import type { TechCategory } from '@/types'

type Diff = 'easy' | 'med' | 'hard'

export default function InterviewDetail() {
  const id = Taro.getCurrentInstance().router?.params?.id
  const isEdit = Boolean(id)
  const questions = useInterviewStore((s) => s.questions)
  const add = useInterviewStore((s) => s.add)
  const update = useInterviewStore((s) => s.update)
  const markReviewed = useInterviewStore((s) => s.markReviewed)
  const remove = useInterviewStore((s) => s.remove)
  const existing = isEdit ? questions.find((q) => q.id === id) : undefined

  const [question, setQuestion] = useState(existing?.question ?? '')
  const [answer, setAnswer] = useState(existing?.answer ?? '')
  const [category, setCategory] = useState<TechCategory>(existing?.category ?? 'frontend')
  const [difficulty, setDifficulty] = useState<Diff>(existing?.difficulty ?? 'med')

  useEffect(() => { Taro.setNavigationBarTitle({ title: isEdit ? '编辑题目' : '新建题目' }) }, [isEdit])

  const save = () => {
    const q = question.trim(), a = answer.trim()
    if (!q) return Taro.showToast({ title: '请输入问题', icon: 'none' })
    if (!a) return Taro.showToast({ title: '请输入答案', icon: 'none' })
    if (isEdit && existing) update(existing.id, { question: q, answer: a, category, difficulty })
    else add({ question: q, answer: a, category, difficulty })
    Taro.showToast({ title: '已保存', icon: 'success' })
    setTimeout(() => Taro.navigateBack(), 400)
  }
  const onMark = () => { if (existing) { markReviewed(existing.id); Taro.showToast({ title: `已复习 ${existing.reviewCount + 1} 次`, icon: 'success' }) } }
  const onDelete = () => {
    if (!existing) return
    Taro.showModal({ title: '删除?', success: (m) => { if (m.confirm) { remove(existing.id); Taro.navigateBack() } } })
  }

  return (
    <View style={{ minHeight: '100vh', padding: '24rpx', background: 'var(--bg-primary)' }}>
      <Header title={isEdit ? '编辑题目' : '新建题目'} showBack
        rightSlot={<Text style={{ color: 'var(--brand)' }} onClick={save}>保存</Text>} />
      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>问题</Text>
        <Textarea value={question} onInput={(e) => setQuestion((e.detail as any).value)} autoHeight
          style={{ width: '100%', minHeight: '160rpx', padding: '24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '28rpx', marginTop: '8rpx', color: 'var(--text-primary)' }}
        />
      </View>
      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>分类</Text>
        <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginTop: '8rpx' }}>
          {Object.entries(TechCategoryMap).map(([key, info]) => (
            <View key={key}
              className={`tag-row__item${category === key ? ' tag-row__item--active' : ''}`}
              onClick={() => setCategory(key as TechCategory)}
              style={category === key ? { background: info.color, borderColor: info.color } : undefined}>
              {info.emoji} {info.label}
            </View>
          ))}
        </View>
      </View>
      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>难度</Text>
        <View style={{ display: 'flex', gap: '8rpx', marginTop: '8rpx' }}>
          {(['easy', 'med', 'hard'] as const).map((d) => (
            <View key={d}
              className={`tag-row__item${difficulty === d ? ' tag-row__item--active' : ''}`}
              onClick={() => setDifficulty(d)}>
              {d === 'easy' ? '简单' : d === 'med' ? '中等' : '困难'}
            </View>
          ))}
        </View>
      </View>
      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>答案 / 思路</Text>
        <Textarea value={answer} onInput={(e) => setAnswer((e.detail as any).value)} autoHeight
          style={{ width: '100%', minHeight: '400rpx', padding: '24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '28rpx', marginTop: '8rpx', color: 'var(--text-primary)' }}
        />
      </View>
      <View style={{ display: 'flex', gap: '16rpx', marginTop: '32rpx' }}>
        <View className='detail__btn detail__btn--ghost' onClick={() => Taro.navigateBack()}>取消</View>
        <View className='detail__btn detail__btn--primary' onClick={save}>保存</View>
      </View>
      {isEdit && existing && (
        <View style={{ marginTop: '24rpx' }}>
          <View className='detail__btn detail__btn--ghost' style={{ color: 'var(--accent)' }} onClick={onMark}>
            ✓ 标记为已复习 (当前 {existing.reviewCount} 次)
          </View>
          <View className='detail__btn detail__btn--ghost' style={{ marginTop: '16rpx', color: 'var(--danger)' }} onClick={onDelete}>删除</View>
        </View>
      )}
    </View>
  )
}
