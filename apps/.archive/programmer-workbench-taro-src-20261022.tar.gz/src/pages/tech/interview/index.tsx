import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useInterviewStore } from '@/stores/interview-store'
import { TechCategoryMap } from '@/stores/tech-notes-store'
import { Empty } from '@/components/common/Empty'
import { formatRelative } from '@/utils/date'
import type { TechCategory } from '@/types'

type DiffFilter = 'all' | 'easy' | 'med' | 'hard'

export default function InterviewList() {
  const questions = useInterviewStore((s) => s.questions)
  const toggleStar = useInterviewStore((s) => s.toggleStar)
  const markReviewed = useInterviewStore((s) => s.markReviewed)
  const remove = useInterviewStore((s) => s.remove)
  const [cat, setCat] = useState<'all' | TechCategory>('all')
  const [diff, setDiff] = useState<DiffFilter>('all')
  const [starOnly, setStarOnly] = useState(false)

  const filtered = useMemo(() => {
    let list = questions
    if (cat !== 'all') list = list.filter((q) => q.category === cat)
    if (diff !== 'all') list = list.filter((q) => q.difficulty === diff)
    if (starOnly) list = list.filter((q) => q.starred)
    return [...list].sort((a, b) =>
      a.starred !== b.starred ? (a.starred ? -1 : 1) :
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [questions, cat, diff, starOnly])

  const onCreate = () => Taro.navigateTo({ url: '/pages/tech/interview/detail' })
  const onOpen = (id: string) => Taro.navigateTo({ url: `/pages/tech/interview/detail?id=${id}` })
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['标记已复习', '编辑', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) { markReviewed(id); Taro.showToast({ title: '已记录', icon: 'success' }) }
        else if (r.tapIndex === 1) onOpen(id)
        else if (r.tapIndex === 2) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginBottom: '16rpx' }}>
        <View className={`tag-row__item${cat === 'all' ? ' tag-row__item--active' : ''}`} onClick={() => setCat('all')}>全部</View>
        {Object.entries(TechCategoryMap).map(([key, info]) => (
          <View key={key}
            className={`tag-row__item${cat === key ? ' tag-row__item--active' : ''}`}
            onClick={() => setCat(key as TechCategory)}
            style={cat === key ? { background: info.color, borderColor: info.color } : undefined}>
            {info.emoji} {info.label}
          </View>
        ))}
      </View>
      <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx', marginBottom: '24rpx' }}>
        <View style={{ display: 'flex', gap: '8rpx' }}>
          {(['all', 'easy', 'med', 'hard'] as const).map((d) => (
            <View key={d}
              className={`tag-row__item${diff === d ? ' tag-row__item--active' : ''}`}
              onClick={() => setDiff(d)}>
              {d === 'all' ? '全部难度' : d === 'easy' ? '简单' : d === 'med' ? '中等' : '困难'}
            </View>
          ))}
        </View>
        <Text
          style={{ marginLeft: 'auto', padding: '8rpx 20rpx', borderRadius: '999rpx', background: starOnly ? 'var(--brand)' : 'var(--bg-secondary)', color: starOnly ? 'white' : 'var(--text-secondary)', fontSize: '24rpx' }}
          onClick={() => setStarOnly(!starOnly)}>
          {starOnly ? '★ 仅收藏' : '☆ 仅收藏'}
        </Text>
      </View>
      {filtered.length === 0 && <Empty icon='🎯' title='还没有面试题' actionText='添加一道' onAction={onCreate} />}
      {filtered.map((q) => (
        <View key={q.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)' }}
          onClick={() => onOpen(q.id)} onLongPress={() => onLongPress(q.id)}>
          <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16rpx' }}>
            <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)', flex: 1, lineHeight: 1.5 }}>{q.question}</Text>
            <Text style={{ marginLeft: '16rpx', color: q.starred ? 'var(--warning)' : 'var(--text-muted)', fontSize: '32rpx' }}
              onClick={(e) => { e?.stopPropagation?.(); toggleStar(q.id) }}>
              {q.starred ? '★' : '☆'}
            </Text>
          </View>
          <View className='line-clamp-3' style={{ fontSize: '26rpx', color: 'var(--text-secondary)', lineHeight: 1.7, background: 'var(--bg-tertiary)', padding: '16rpx', borderRadius: '12rpx', marginTop: '16rpx', whiteSpace: 'pre-wrap' }}>
            {q.answer}
          </View>
          <View style={{ display: 'flex', flexWrap: 'wrap', gap: '4rpx', alignItems: 'center', marginTop: '16rpx' }}>
            <View style={{ padding: '4rpx 14rpx', borderRadius: '999rpx', fontSize: '22rpx',
              background: q.difficulty === 'easy' ? 'var(--success-soft)' : q.difficulty === 'med' ? 'var(--warning-soft)' : 'var(--danger-soft)',
              color: q.difficulty === 'easy' ? 'var(--success)' : q.difficulty === 'med' ? 'var(--warning)' : 'var(--danger)' }}>
              <Text>{q.difficulty === 'easy' ? '简单' : q.difficulty === 'med' ? '中等' : '困难'}</Text>
            </View>
            <View style={{ padding: '4rpx 14rpx', borderRadius: '999rpx', fontSize: '22rpx', background: `${TechCategoryMap[q.category].color}20`, color: TechCategoryMap[q.category].color }}>
              <Text>{TechCategoryMap[q.category].label}</Text>
            </View>
            <Text style={{ marginLeft: 'auto', fontSize: '22rpx', color: 'var(--text-muted)' }}>
              复习 {q.reviewCount} 次 · {q.lastReviewed ? formatRelative(q.lastReviewed) : '未复习'}
            </Text>
          </View>
        </View>
      ))}
      <View className='fab' onClick={onCreate}>+</View>
    </View>
  )
}
