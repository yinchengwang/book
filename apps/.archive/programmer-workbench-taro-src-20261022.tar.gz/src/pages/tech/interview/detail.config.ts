export default definePageConfig({ navigationBarTitleText: '面试题详情', navigationStyle: 'custom' })
