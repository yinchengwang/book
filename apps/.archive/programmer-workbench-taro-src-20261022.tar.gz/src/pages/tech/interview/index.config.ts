export default definePageConfig({ navigationBarTitleText: '面试题库', enablePullDownRefresh: true })
