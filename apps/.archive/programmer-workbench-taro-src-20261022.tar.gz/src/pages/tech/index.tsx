import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useTechNotesStore } from '@/stores/tech-notes-store'
import { useSnippetsStore } from '@/stores/snippets-store'
import { useInterviewStore } from '@/stores/interview-store'
import { useResourcesStore } from '@/stores/resources-store'

const QUOTES = [
  { text: 'Talk is cheap. Show me the code.', author: 'Linus Torvalds' },
  { text: 'Simplicity is the ultimate sophistication.', author: 'Leonardo da Vinci' },
  { text: 'First, solve the problem. Then, write the code.', author: 'John Johnson' },
  { text: 'Make it work, make it right, make it fast.', author: 'Kent Beck' }
]

export default function TechIndex() {
  const notesCount = useTechNotesStore((s) => s.notes.length)
  const snippetsCount = useSnippetsStore((s) => s.snippets.length)
  const interviewCount = useInterviewStore((s) => s.questions.length)
  const resourcesCount = useResourcesStore((s) => s.resources.filter((r) => !r.archived).length)
  const today = new Date()
  const quote = QUOTES[today.getDate() % QUOTES.length]
  const goto = (url: string) => Taro.navigateTo({ url })

  const modules = [
    { emoji: '📚', title: '技术笔记', desc: '沉淀日常学习,Markdown 快速记录', count: notesCount, path: '/pages/tech/notes/index' },
    { emoji: '📝', title: '代码片段', desc: '高频代码片段集中收藏', count: snippetsCount, path: '/pages/tech/snippets/index' },
    { emoji: '🎯', title: '面试题库', desc: '分类整理难题,支持复习计数', count: interviewCount, path: '/pages/tech/interview/index' },
    { emoji: '🔖', title: '资源收藏', desc: '文章、视频、仓库一键归档', count: resourcesCount, path: '/pages/tech/resources/index' }
  ]

  return (
    <View className='page-container'>
      <View style={{ padding: '0 0 24rpx' }}>
        <Text style={{ fontSize: '48rpx', fontWeight: 800, color: 'var(--text-primary)' }}>技术栈</Text>
        <View style={{ fontSize: '24rpx', color: 'var(--text-muted)', marginTop: '4rpx' }}>学之, 习之, 沉淀之</View>
      </View>

      <View style={{ padding: '24rpx', borderRadius: '24rpx', background: 'linear-gradient(135deg, var(--brand) 0%, var(--accent) 100%)', color: 'white' }}>
        <Text style={{ fontSize: '28rpx', lineHeight: 1.5, opacity: 0.95 }}>"{quote.text}"</Text>
        <View style={{ marginTop: '8rpx', fontSize: '22rpx', opacity: 0.8, textAlign: 'right' }}>
          <Text>— {quote.author}</Text>
        </View>
      </View>

      <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '24rpx', borderRadius: '24rpx', background: 'var(--bg-secondary)', marginTop: '24rpx', boxShadow: 'var(--shadow-sm)' }}>
        <View style={{ flex: 1, paddingRight: '24rpx' }}>
          <View style={{ fontSize: '28rpx', fontWeight: 700 }}>每天进步 1%</View>
          <View style={{ fontSize: '22rpx', color: 'var(--text-muted)', marginTop: '4rpx' }}>
            累计学习 {notesCount + snippetsCount + interviewCount} 项,知识正在指数级累积
          </View>
        </View>
        <View style={{ width: '80rpx', height: '80rpx', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '44rpx', background: 'var(--warning-soft)' }}>🔥</View>
      </View>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' />
          <Text className='section-title__text'>学习模块</Text>
        </View>
      </View>

      <View style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16rpx' }}>
        {modules.map((m) => (
          <View key={m.path}
            style={{ display: 'flex', flexDirection: 'column', padding: '24rpx', borderRadius: '24rpx', background: 'var(--bg-secondary)', boxShadow: 'var(--shadow-sm)' }}
            onClick={() => goto(m.path)}>
            <View style={{ fontSize: '56rpx', marginBottom: '16rpx' }}>{m.emoji}</View>
            <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '4rpx' }}>{m.title}</Text>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)', lineHeight: 1.5 }}>{m.desc}</Text>
            <View style={{ marginTop: '16rpx', display: 'inline-flex', alignItems: 'center', padding: '4rpx 14rpx', background: 'var(--brand-soft)', color: 'var(--brand)', borderRadius: '999rpx', fontSize: '22rpx', alignSelf: 'flex-start' }}>
              <Text>{m.count} 项</Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  )
}
