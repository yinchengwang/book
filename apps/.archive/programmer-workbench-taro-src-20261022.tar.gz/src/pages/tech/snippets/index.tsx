import { View, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useSnippetsStore, LanguageMap } from '@/stores/snippets-store'
import { Empty } from '@/components/common/Empty'
import { formatRelative } from '@/utils/date'
import type { SnippetLanguage } from '@/types'

type Filter = 'all' | SnippetLanguage

export default function SnippetsList() {
  const snippets = useSnippetsStore((s) => s.snippets)
  const toggleFav = useSnippetsStore((s) => s.toggleFav)
  const remove = useSnippetsStore((s) => s.remove)
  const [kw, setKw] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [favOnly, setFavOnly] = useState(false)

  const filtered = useMemo(() => {
    let list = snippets
    if (filter !== 'all') list = list.filter((s) => s.language === filter)
    if (favOnly) list = list.filter((s) => s.favorite)
    const k = kw.trim().toLowerCase()
    if (k) list = list.filter((s) =>
      s.title.toLowerCase().includes(k) || s.code.toLowerCase().includes(k) || s.tags.some((t) => t.toLowerCase().includes(k))
    )
    return [...list].sort((a, b) =>
      a.favorite !== b.favorite ? (a.favorite ? -1 : 1) :
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [snippets, kw, filter, favOnly])

  const onOpen = (id: string) => Taro.navigateTo({ url: `/pages/tech/snippets/detail?id=${id}` })
  const onCreate = () => Taro.navigateTo({ url: '/pages/tech/snippets/detail' })
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['收藏/取消', '编辑', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) toggleFav(id)
        else if (r.tapIndex === 1) onOpen(id)
        else if (r.tapIndex === 2) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ display: 'flex', gap: '16rpx', marginBottom: '24rpx' }}>
        <Input placeholder='🔍 搜索片段内容' value={kw} onInput={(e) => setKw((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '36rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', fontSize: '26rpx', color: 'var(--text-primary)' }}
        />
        <View
          style={{ width: '72rpx', height: '72rpx', borderRadius: '50%', background: favOnly ? 'var(--brand)' : 'var(--bg-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '30rpx', color: favOnly ? 'white' : 'var(--text-secondary)' }}
          onClick={() => setFavOnly(!favOnly)}
        >★</View>
      </View>

      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginBottom: '24rpx' }}>
        <View className={`tag-row__item${filter === 'all' ? ' tag-row__item--active' : ''}`} onClick={() => setFilter('all')}>全部</View>
        {Object.entries(LanguageMap).map(([key, info]) => (
          <View key={key}
            className={`tag-row__item${filter === key ? ' tag-row__item--active' : ''}`}
            onClick={() => setFilter(key as SnippetLanguage)}
            style={filter === key ? { background: info.color, borderColor: info.color } : undefined}>
            {info.label}
          </View>
        ))}
      </View>

      {filtered.length === 0 && <Empty icon='📝' title='还没有片段' actionText='新建片段' onAction={onCreate} />}

      {filtered.map((s) => (
        <View key={s.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)' }}
          onClick={() => onOpen(s.id)} onLongPress={() => onLongPress(s.id)}>
          <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16rpx' }}>
            <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)', flex: 1, overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{s.title}</Text>
            <View style={{ marginLeft: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: LanguageMap[s.language].color, color: 'white', fontSize: '22rpx', fontWeight: 600 }}>
              <Text>{LanguageMap[s.language].label}</Text>
            </View>
          </View>
          <View style={{ background: '#0f172a', color: '#e2e8f0', padding: '16rpx', borderRadius: '12rpx', fontFamily: 'Menlo,Monaco,Consolas,monospace', fontSize: '22rpx', lineHeight: 1.5, whiteSpace: 'pre', overflowX: 'auto', maxHeight: '200rpx' }}>
            {s.code.slice(0, 160)}{s.code.length > 160 ? '\n...' : ''}
          </View>
          <View style={{ display: 'flex', justifyContent: 'space-between', marginTop: '16rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
            <Text>{formatRelative(s.createdAt)}</Text>
            <Text style={{ color: s.favorite ? 'var(--warning)' : 'var(--text-muted)', fontSize: '32rpx' }}
              onClick={(e) => { e?.stopPropagation?.(); toggleFav(s.id) }}>
              {s.favorite ? '★' : '☆'}
            </Text>
          </View>
        </View>
      ))}
      <View className='fab' onClick={onCreate}>+</View>
    </View>
  )
}
