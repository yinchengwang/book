export default definePageConfig({ navigationBarTitleText: '代码片段', enablePullDownRefresh: true })
