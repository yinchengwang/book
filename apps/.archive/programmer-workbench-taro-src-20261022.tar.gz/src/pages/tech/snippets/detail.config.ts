export default definePageConfig({ navigationBarTitleText: '代码片段详情', navigationStyle: 'custom' })
