import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useState, useEffect } from 'react'
import { useSnippetsStore, LanguageMap } from '@/stores/snippets-store'
import { Header } from '@/components/common/Header'
import type { SnippetLanguage } from '@/types'

export default function SnippetDetail() {
  const id = Taro.getCurrentInstance().router?.params?.id
  const isEdit = Boolean(id)
  const snippets = useSnippetsStore((s) => s.snippets)
  const add = useSnippetsStore((s) => s.add)
  const update = useSnippetsStore((s) => s.update)
  const remove = useSnippetsStore((s) => s.remove)
  const existing = isEdit ? snippets.find((s) => s.id === id) : undefined

  const [title, setTitle] = useState(existing?.title ?? '')
  const [language, setLanguage] = useState<SnippetLanguage>(existing?.language ?? 'typescript')
  const [code, setCode] = useState(existing?.code ?? '// your snippet')
  const [description, setDescription] = useState(existing?.description ?? '')
  const [tagsText, setTagsText] = useState(existing?.tags.join(', ') ?? '')

  useEffect(() => { Taro.setNavigationBarTitle({ title: isEdit ? '编辑片段' : '新建片段' }) }, [isEdit])

  const copyCode = () => Taro.setClipboardData({ data: code, success: () => Taro.showToast({ title: '已复制', icon: 'success' }) })

  const save = () => {
    const t = title.trim()
    if (!t) return Taro.showToast({ title: '请输入标题', icon: 'none' })
    const tags = tagsText.split(/[,，\s]+/).map((x) => x.trim().replace(/^#/, '')).filter(Boolean)
    if (isEdit && existing) update(existing.id, { title: t, language, code, description, tags })
    else add({ title: t, language, code, description, tags })
    Taro.showToast({ title: '已保存', icon: 'success' })
    setTimeout(() => Taro.navigateBack(), 400)
  }

  const onDelete = () => {
    if (!existing) return
    Taro.showModal({ title: '删除?', success: (m) => { if (m.confirm) { remove(existing.id); Taro.navigateBack() } } })
  }

  return (
    <View style={{ minHeight: '100vh', padding: '24rpx', background: 'var(--bg-primary)' }}>
      <Header title={isEdit ? '编辑片段' : '新建片段'} showBack
        rightSlot={
          <View style={{ display: 'flex', gap: '16rpx' }}>
            <Text style={{ color: 'var(--text-secondary)' }} onClick={copyCode}>📋 复制</Text>
            <Text style={{ color: 'var(--brand)' }} onClick={save}>保存</Text>
          </View>
        }
      />

      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>标题</Text>
        <Input value={title} onInput={(e) => setTitle((e.detail as any).value)}
          style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '26rpx', marginTop: '8rpx', color: 'var(--text-primary)' }} />
      </View>

      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>语言</Text>
        <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginTop: '8rpx' }}>
          {Object.entries(LanguageMap).map(([key, info]) => (
            <View key={key}
              className={`tag-row__item${language === key ? ' tag-row__item--active' : ''}`}
              onClick={() => setLanguage(key as SnippetLanguage)}
              style={language === key ? { background: info.color, borderColor: info.color } : undefined}>
              {info.label}
            </View>
          ))}
        </View>
      </View>

      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>说明</Text>
        <Input value={description} onInput={(e) => setDescription((e.detail as any).value)}
          style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '26rpx', marginTop: '8rpx', color: 'var(--text-primary)' }} />
      </View>

      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>标签</Text>
        <Input value={tagsText} onInput={(e) => setTagsText((e.detail as any).value)}
          style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-secondary)', fontSize: '26rpx', marginTop: '8rpx', color: 'var(--text-primary)' }} />
      </View>

      <View style={{ marginBottom: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>代码</Text>
        <Textarea value={code} onInput={(e) => setCode((e.detail as any).value)} autoHeight
          style={{ width: '100%', minHeight: '400rpx', padding: '24rpx', borderRadius: '16rpx', background: '#0f172a', color: '#e2e8f0', fontFamily: 'Menlo,Monaco,monospace', fontSize: '26rpx', lineHeight: 1.6, marginTop: '8rpx' }} />
      </View>

      <View style={{ display: 'flex', gap: '16rpx', marginTop: '32rpx' }}>
        <View className='detail__btn detail__btn--ghost' onClick={() => Taro.navigateBack()}>取消</View>
        <View className='detail__btn detail__btn--primary' onClick={save}>保存</View>
      </View>
      {isEdit && (
        <View className='detail__btn detail__btn--ghost' style={{ marginTop: '24rpx', color: 'var(--danger)' }} onClick={onDelete}>删除片段</View>
      )}
    </View>
  )
}
