export default definePageConfig({ navigationBarTitleText: '资源收藏', enablePullDownRefresh: true })
