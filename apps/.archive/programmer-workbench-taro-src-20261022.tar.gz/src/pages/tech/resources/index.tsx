import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useResourcesStore } from '@/stores/resources-store'
import { TechCategoryMap } from '@/stores/tech-notes-store'
import { Empty } from '@/components/common/Empty'
import type { ResourceType, TechCategory } from '@/types'

const TYPE_META: Record<ResourceType, { label: string; emoji: string }> = {
  article: { label: '文章', emoji: '📰' },
  video:   { label: '视频', emoji: '🎬' },
  book:    { label: '书籍', emoji: '📖' },
  repo:    { label: '仓库', emoji: '📦' },
  tool:    { label: '工具', emoji: '🔧' },
  doc:     { label: '文档', emoji: '📄' }
}

export default function ResourcesList() {
  const resources = useResourcesStore((s) => s.resources)
  const add = useResourcesStore((s) => s.add)
  const toggleArchive = useResourcesStore((s) => s.toggleArchive)
  const remove = useResourcesStore((s) => s.remove)

  const [cat, setCat] = useState<'all' | TechCategory>('all')
  const [type, setType] = useState<'all' | ResourceType>('all')
  const [showArchive, setShowArchive] = useState(false)
  const [showModal, setShowModal] = useState(false)

  const [m_title, setMTitle] = useState('')
  const [m_url, setMUrl] = useState('')
  const [m_type, setMType] = useState<ResourceType>('article')
  const [m_category, setMCategory] = useState<TechCategory>('frontend')
  const [m_stars, setMStars] = useState(3)
  const [m_note, setMNote] = useState('')

  const filtered = useMemo(() => {
    let list = resources
    if (!showArchive) list = list.filter((r) => !r.archived)
    if (cat !== 'all') list = list.filter((r) => r.category === cat)
    if (type !== 'all') list = list.filter((r) => r.type === type)
    return [...list].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [resources, showArchive, cat, type])

  const openCreate = () => {
    setMTitle(''); setMUrl(''); setMType('article'); setMCategory('frontend'); setMStars(3); setMNote('')
    setShowModal(true)
  }
  const submit = () => {
    if (!m_title.trim()) return Taro.showToast({ title: '请输入标题', icon: 'none' })
    add({ title: m_title.trim(), url: m_url.trim() || undefined, type: m_type, category: m_category, stars: m_stars, note: m_note.trim() || undefined })
    setShowModal(false)
    Taro.showToast({ title: '已收藏', icon: 'success' })
  }
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['归档/取消归档', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) toggleArchive(id)
        else if (r.tapIndex === 1) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }
  const onOpen = (url?: string) => {
    if (!url) return Taro.showToast({ title: '没有链接', icon: 'none' })
    Taro.setClipboardData({ data: url, success: () => Taro.showModal({ title: '链接已复制', content: url, confirmText: '好的', showCancel: false }) })
  }

  return (
    <View className='page-container'>
      <View style={{ display: 'flex', gap: '16rpx', marginBottom: '24rpx' }}>
        <View
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '36rpx', background: 'var(--bg-secondary)', border: '1rpx solid var(--border)', display: 'flex', alignItems: 'center' }}
          onClick={openCreate}>
          <Text style={{ color: 'var(--text-muted)', fontSize: '26rpx' }}>+ 添加一条资源...</Text>
        </View>
        <View
          style={{ padding: '0 24rpx', height: '72rpx', borderRadius: '36rpx', background: showArchive ? 'var(--bg-tertiary)' : 'var(--bg-secondary)', border: '1rpx solid var(--border)', display: 'flex', alignItems: 'center', fontSize: '24rpx', color: 'var(--text-secondary)' }}
          onClick={() => setShowArchive(!showArchive)}>
          {showArchive ? '📂 归档' : '🗂 全部'}
        </View>
      </View>

      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginBottom: '16rpx' }}>
        <View className={`tag-row__item${type === 'all' ? ' tag-row__item--active' : ''}`} onClick={() => setType('all')}>全部类型</View>
        {Object.entries(TYPE_META).map(([k, v]) => (
          <View key={k}
            className={`tag-row__item${type === k ? ' tag-row__item--active' : ''}`}
            onClick={() => setType(k as ResourceType)}>
            {v.emoji} {v.label}
          </View>
        ))}
      </View>
      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginBottom: '24rpx' }}>
        <View className={`tag-row__item${cat === 'all' ? ' tag-row__item--active' : ''}`} onClick={() => setCat('all')}>全部分类</View>
        {Object.entries(TechCategoryMap).map(([key, info]) => (
          <View key={key}
            className={`tag-row__item${cat === key ? ' tag-row__item--active' : ''}`}
            onClick={() => setCat(key as TechCategory)}
            style={cat === key ? { background: info.color, borderColor: info.color } : undefined}>
            {info.emoji} {info.label}
          </View>
        ))}
      </View>

      {filtered.length === 0 && <Empty icon='🔖' title='还没有资源' actionText='添加资源' onAction={openCreate} />}
      {filtered.map((r) => (
        <View key={r.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)' }}
          onClick={() => onOpen(r.url)} onLongPress={() => onLongPress(r.id)}>
          <View style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16rpx' }}>
            <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)', flex: 1, wordBreak: 'break-all' }}>{r.title}</Text>
            <View style={{ marginLeft: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', fontSize: '22rpx', background: 'var(--accent-soft)', color: 'var(--accent)', flexShrink: 0 }}>
              <Text>{TYPE_META[r.type].emoji} {TYPE_META[r.type].label}</Text>
            </View>
          </View>
          {r.url && <Text style={{ fontSize: '22rpx', color: 'var(--brand)', marginBottom: '16rpx', wordBreak: 'break-all', lineHeight: 1.5 }}>{r.url}</Text>}
          {r.note && <Text style={{ fontSize: '24rpx', color: 'var(--text-secondary)', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', marginBottom: '16rpx', lineHeight: 1.6 }}>{r.note}</Text>}
          <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '22rpx', color: 'var(--text-muted)' }}>
            <View style={{ padding: '4rpx 14rpx', borderRadius: '999rpx', background: `${TechCategoryMap[r.category].color}20`, color: TechCategoryMap[r.category].color }}>
              <Text>{TechCategoryMap[r.category].label}</Text>
            </View>
            <Text style={{ color: 'var(--warning)' }}>{'★'.repeat(r.stars)}{'☆'.repeat(5 - r.stars)}</Text>
          </View>
        </View>
      ))}

      {showModal && (
        <View className='modal-mask' onClick={() => setShowModal(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>收藏资源</View>
            <ModalField label='标题'><Input value={m_title} onInput={(e) => setMTitle((e.detail as any).value)}
              style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} /></ModalField>
            <ModalField label='链接(可选)'><Input value={m_url} onInput={(e) => setMUrl((e.detail as any).value)}
              style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} /></ModalField>
            <ModalField label='类型'>
              <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx' }}>
                {Object.entries(TYPE_META).map(([k, v]) => (
                  <View key={k} className={`tag-row__item${m_type === k ? ' tag-row__item--active' : ''}`}
                    onClick={() => setMType(k as ResourceType)}>{v.emoji} {v.label}</View>
                ))}
              </View>
            </ModalField>
            <ModalField label='分类'>
              <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx' }}>
                {Object.entries(TechCategoryMap).map(([key, info]) => (
                  <View key={key} className={`tag-row__item${m_category === key ? ' tag-row__item--active' : ''}`}
                    onClick={() => setMCategory(key as TechCategory)}
                    style={m_category === key ? { background: info.color, borderColor: info.color } : undefined}>
                    {info.emoji} {info.label}
                  </View>
                ))}
              </View>
            </ModalField>
            <ModalField label='评分'>
              <View style={{ display: 'flex', gap: '12rpx', fontSize: '40rpx' }}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <Text key={n} style={{ color: n <= m_stars ? 'var(--warning)' : 'var(--text-muted)' }} onClick={() => setMStars(n)}>
                    {n <= m_stars ? '★' : '☆'}
                  </Text>
                ))}
              </View>
            </ModalField>
            <ModalField label='备注'>
              <Textarea value={m_note} onInput={(e) => setMNote((e.detail as any).value)} autoHeight
                style={{ width: '100%', minHeight: '140rpx', padding: '16rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
            </ModalField>
            <View style={{ display: 'flex', gap: '16rpx', marginTop: '24rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowModal(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submit}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}

function ModalField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: '16rpx' }}>
      <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)', marginBottom: '4rpx' }}>{label}</Text>
      {children}
    </View>
  )
}
