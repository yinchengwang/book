import { View, Text, Textarea, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import {
  base64Encode, base64Decode,
  urlEncode, urlDecode,
  jsonTransform,
  tsNow, tsToDate, dateToTs, fmtDate,
  uuid, randomString,
  hexToRgb, rgbToHex,
  testRegex,
  djb2, crc32,
  diffText,
  describeCron
} from '@/utils/codetools'

interface ToolMeta { id: string; emoji: string; label: string }
const TOOLS: ToolMeta[] = [
  { id: 'json', emoji: '🧾', label: 'JSON' },
  { id: 'base64', emoji: '🔤', label: 'Base64' },
  { id: 'url', emoji: '🔗', label: 'URL' },
  { id: 'timestamp', emoji: '⏰', label: '时间戳' },
  { id: 'uuid', emoji: '🆔', label: 'UUID' },
  { id: 'regex', emoji: '🧪', label: '正则' },
  { id: 'color', emoji: '🎨', label: '颜色' },
  { id: 'hash', emoji: '#️⃣', label: 'Hash' },
  { id: 'diff', emoji: '🔁', label: 'Diff' },
  { id: 'cron', emoji: '⏳', label: 'Cron' }
]

const copy = (text: string) => Taro.setClipboardData({ data: text, success: () => Taro.showToast({ title: '已复制', icon: 'success' }) })
const panelStyle: React.CSSProperties = {
  background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', boxShadow: 'var(--shadow-sm)'
}
const inputStyle: React.CSSProperties = {
  width: '100%', minHeight: '200rpx', padding: '16rpx', borderRadius: '16rpx',
  background: 'var(--bg-tertiary)', fontSize: '26rpx', fontFamily: 'Menlo,Monaco,monospace',
  color: 'var(--text-primary)', lineHeight: 1.5
}
const outputStyle: React.CSSProperties = {
  width: '100%', minHeight: '200rpx', padding: '16rpx', borderRadius: '16rpx',
  background: '#0f172a', color: '#e2e8f0', fontSize: '26rpx', fontFamily: 'Menlo,Monaco,monospace',
  lineHeight: 1.5, wordBreak: 'break-all', whiteSpace: 'pre-wrap', overflowWrap: 'anywhere'
}

export default function ToolsPage() {
  const [toolId, setToolId] = useState('json')
  return (
    <View className='page-container'>
      <View style={{ padding: '0 0 24rpx' }}>
        <Text style={{ fontSize: '44rpx', fontWeight: 800, color: 'var(--text-primary)' }}>工具箱</Text>
        <View style={{ fontSize: '24rpx', color: 'var(--text-muted)', marginTop: '8rpx' }}>离线即用,无需上传,所见即所得</View>
      </View>

      <View style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '16rpx', marginBottom: '24rpx' }}>
        {TOOLS.map((t) => (
          <View key={t.id}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16rpx 0', borderRadius: '16rpx', background: toolId === t.id ? 'var(--brand)' : 'var(--bg-secondary)', color: toolId === t.id ? 'white' : 'var(--text-primary)', boxShadow: 'var(--shadow-sm)' }}
            onClick={() => setToolId(t.id)}>
            <View style={{ fontSize: '40rpx', marginBottom: '4rpx' }}>{t.emoji}</View>
            <Text style={{ fontSize: '22rpx' }}>{t.label}</Text>
          </View>
        ))}
      </View>

      {toolId === 'json' && <JsonTool />}
      {toolId === 'base64' && <Base64Tool />}
      {toolId === 'url' && <UrlTool />}
      {toolId === 'timestamp' && <TimestampTool />}
      {toolId === 'uuid' && <UuidTool />}
      {toolId === 'regex' && <RegexTool />}
      {toolId === 'color' && <ColorTool />}
      {toolId === 'hash' && <HashTool />}
      {toolId === 'diff' && <DiffTool />}
      {toolId === 'cron' && <CronTool />}
    </View>
  )
}

function JsonTool() {
  const [input, setInput] = useState('{"name":"DevBencHer","tags":["work","book"]}')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  const run = (mode: 'beautify' | 'minify' | 'escape' | 'unescape') => {
    try { setOutput(jsonTransform(input, mode)); setError('') }
    catch (e: any) { setError(e?.message ?? String(e)); setOutput('') }
  }
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>JSON 格式化 / 转义</Text>
      <Textarea value={input} onInput={(e) => setInput((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '16rpx' }} />
      <View style={{ display: 'flex', gap: '16rpx', marginTop: '16rpx', flexWrap: 'wrap' }}>
        {(['beautify', 'minify', 'escape', 'unescape'] as const).map((m, i) => (
          <View key={m} className={i === 0 ? 'detail__btn detail__btn--primary' : 'detail__btn detail__btn--ghost'}
            style={{ flex: 1 }} onClick={() => run(m)}>
            {m === 'beautify' ? '美化' : m === 'minify' ? '压缩' : m === 'escape' ? '转义' : '反转义'}
          </View>
        ))}
      </View>
      {error ? <Text style={{ marginTop: '16rpx', color: 'var(--danger)', fontSize: '24rpx' }}>❌ {error}</Text> : null}
      {output && (
        <View style={{ position: 'relative', marginTop: '16rpx' }}>
          <View style={outputStyle}>{output}</View>
          <View style={{ position: 'absolute', top: '16rpx', right: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'rgba(255,255,255,0.15)', color: 'white', fontSize: '22rpx' }} onClick={() => copy(output)}>复制</View>
        </View>
      )}
    </View>
  )
}

function Base64Tool() {
  const [input, setInput] = useState('Hello, DevBench! 你好,程序员')
  const [out, setOut] = useState('')
  const [err, setErr] = useState('')
  const encode = () => { try { setOut(base64Encode(input)); setErr('') } catch (e: any) { setErr(e?.message ?? '') } }
  const decode = () => { try { setOut(base64Decode(input)); setErr('') } catch { setErr('⚠️ 不是合法 Base64 字符串') } }
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>Base64 编解码</Text>
      <Textarea value={input} onInput={(e) => setInput((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '16rpx' }} />
      <View style={{ display: 'flex', gap: '16rpx', marginTop: '16rpx' }}>
        <View className='detail__btn detail__btn--primary' style={{ flex: 1 }} onClick={encode}>编码 →</View>
        <View className='detail__btn detail__btn--ghost' style={{ flex: 1 }} onClick={decode}>← 解码</View>
      </View>
      {err && <Text style={{ marginTop: '16rpx', color: 'var(--danger)' }}>{err}</Text>}
      {out && (
        <View style={{ position: 'relative', marginTop: '16rpx' }}>
          <View style={outputStyle}>{out}</View>
          <View style={{ position: 'absolute', top: '16rpx', right: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'rgba(255,255,255,0.15)', color: 'white', fontSize: '22rpx' }} onClick={() => copy(out)}>复制</View>
        </View>
      )}
    </View>
  )
}

function UrlTool() {
  const [input, setInput] = useState('https://example.com/?q=程序员工作台&name=DevBench')
  const [out, setOut] = useState('')
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>URL 编码 / 解码</Text>
      <Textarea value={input} onInput={(e) => setInput((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '16rpx' }} />
      <View style={{ display: 'flex', gap: '16rpx', marginTop: '16rpx' }}>
        <View className='detail__btn detail__btn--primary' style={{ flex: 1 }} onClick={() => setOut(urlEncode(input))}>编码 →</View>
        <View className='detail__btn detail__btn--ghost' style={{ flex: 1 }} onClick={() => setOut(urlDecode(input))}>← 解码</View>
      </View>
      {out && (
        <View style={{ position: 'relative', marginTop: '16rpx' }}>
          <View style={outputStyle}>{out}</View>
          <View style={{ position: 'absolute', top: '16rpx', right: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'rgba(255,255,255,0.15)', color: 'white', fontSize: '22rpx' }} onClick={() => copy(out)}>复制</View>
        </View>
      )}
    </View>
  )
}

function TimestampTool() {
  const [nowMs, setNowMs] = useState(tsNow('ms'))
  const [nowS, setNowS] = useState(tsNow('s'))
  const [tsInput, setTsInput] = useState(String(tsNow('s')))
  const [dateInput, setDateInput] = useState(fmtDate(new Date(), 'YYYY-MM-DD HH:mm:ss'))
  const [unit, setUnit] = useState<'s' | 'ms'>('s')
  const refresh = () => { setNowMs(tsNow('ms')); setNowS(tsNow('s')) }
  const fromTs = () => { try { setDateInput(fmtDate(tsToDate(tsInput))) } catch { Taro.showToast({ title: '时间戳不合法', icon: 'none' }) } }
  const toTs = () => { try { setTsInput(String(dateToTs(dateInput, unit))) } catch { Taro.showToast({ title: '时间不合法', icon: 'none' }) } }
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>时间戳转换</Text>
      <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)', marginTop: '16rpx' }}>
        当前: <Text style={{ color: 'var(--brand)', fontFamily: 'monospace' }}>{nowS}</Text> s · {nowMs} ms
      </Text>
      <View style={{ display: 'flex', gap: '12rpx', marginTop: '12rpx' }}>
        <View className='detail__btn detail__btn--ghost' onClick={refresh}>刷新</View>
        <View className='detail__btn detail__btn--ghost' onClick={() => copy(String(nowS))}>复制秒级</View>
        <View className='detail__btn detail__btn--ghost' onClick={() => copy(String(nowMs))}>复制毫秒级</View>
      </View>
      <View style={{ marginTop: '24rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>时间戳 → 时间</Text>
        <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginTop: '8rpx' }}>
          <Input value={tsInput} onInput={(e) => setTsInput((e.detail as any).value)}
            style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
          <View className='detail__btn detail__btn--primary' style={{ flex: 'none', padding: '16rpx 32rpx' }} onClick={fromTs}>转换</View>
        </View>
      </View>
      <View style={{ marginTop: '16rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>时间 → 时间戳</Text>
        <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginTop: '8rpx' }}>
          <Input value={dateInput} onInput={(e) => setDateInput((e.detail as any).value)}
            style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
          <View className='detail__btn detail__btn--ghost' style={{ flex: 'none', padding: '16rpx 32rpx' }} onClick={() => setUnit('s')}>秒</View>
          <View className='detail__btn detail__btn--ghost' style={{ flex: 'none', padding: '16rpx 32rpx' }} onClick={() => setUnit('ms')}>毫秒</View>
          <View className='detail__btn detail__btn--primary' style={{ flex: 'none', padding: '16rpx 32rpx' }} onClick={toTs}>转换</View>
        </View>
      </View>
    </View>
  )
}

function UuidTool() {
  const [list, setList] = useState<string[]>([])
  const [len, setLen] = useState('16')
  const [charset, setCharset] = useState<'alphanumeric' | 'digit' | 'lower' | 'upper' | 'strong'>('alphanumeric')
  const generateOne = (n: number, c: typeof charset) => {
    const newList = Array.from({ length: n }, () => {
      if (c === 'digit' || c === 'lower' || c === 'upper' || c === 'strong')
        return randomString(parseInt(len, 10) || 16, c)
      return uuid()
    })
    setList(newList)
  }
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>UUID / 随机字符串</Text>
      <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', margin: '12rpx 0' }}>
        {(['alphanumeric', 'lower', 'upper', 'digit', 'strong'] as const).map((c) => (
          <View key={c} className={`tag-row__item${charset === c ? ' tag-row__item--active' : ''}`} onClick={() => setCharset(c)}>
            {c === 'alphanumeric' ? 'UUID v4' : c === 'lower' ? '小写字母' : c === 'upper' ? '大写字母' : c === 'digit' ? '纯数字' : '含符号'}
          </View>
        ))}
      </View>
      <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginBottom: '12rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>长度</Text>
        <Input type='number' value={len} onInput={(e) => setLen((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <View className='detail__btn detail__btn--primary' style={{ flex: 'none', padding: '16rpx 24rpx' }} onClick={() => generateOne(5, charset)}>生成 5 个</View>
      </View>
      {list.length > 0 && (
        <View style={{ position: 'relative', marginTop: '16rpx' }}>
          <View style={outputStyle}>{list.join('\n')}</View>
          <View style={{ position: 'absolute', top: '16rpx', right: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'rgba(255,255,255,0.15)', color: 'white', fontSize: '22rpx' }} onClick={() => copy(list.join('\n'))}>复制</View>
        </View>
      )}
    </View>
  )
}

function RegexTool() {
  const [pattern, setPattern] = useState('\\b(\\w+)@(\\w+)\\.(\\w+)\\b')
  const [text, setText] = useState('邮箱: alice@example.com, bob@foo.bar')
  const [flags, setFlags] = useState('g')
  const res = useMemo(() => testRegex(pattern, text, flags), [pattern, text, flags])
  const toggleFlag = (f: string) => {
    setFlags(flags.includes(f) ? flags.replace(f, '') : flags + f)
  }
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>正则测试</Text>
      <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginTop: '12rpx' }}>
        <Text style={{ width: '120rpx', color: 'var(--text-muted)' }}>/pattern/</Text>
        <Input value={pattern} onInput={(e) => setPattern((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
      </View>
      <View style={{ display: 'flex', gap: '8rpx', marginTop: '12rpx' }}>
        {['g', 'i', 'm', 's'].map((f) => (
          <View key={f} className={`tag-row__item${flags.includes(f) ? ' tag-row__item--active' : ''}`} onClick={() => toggleFlag(f)}>{f}</View>
        ))}
      </View>
      <Textarea value={text} onInput={(e) => setText((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '16rpx' }} />
      <View style={{ marginTop: '16rpx', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
        {res.error ? <Text style={{ color: 'var(--danger)' }}>❌ {res.error}</Text>
          : <Text>{res.matched ? `匹配 ${res.matchCount} 处` : '无匹配'}</Text>}
      </View>
      {res.highlighted.length > 0 && (
        <View style={{ fontFamily: 'monospace', background: 'var(--bg-tertiary)', padding: '16rpx', borderRadius: '12rpx', marginTop: '12rpx', whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: 'var(--text-primary)', fontSize: '26rpx' }}>
          {res.highlighted.map((s, i) => (
            <Text key={i} style={s.hit ? { background: 'var(--brand)', color: 'white', padding: '2rpx 4rpx', borderRadius: '4rpx' } : undefined}>{s.value}</Text>
          ))}
        </View>
      )}
    </View>
  )
}

function ColorTool() {
  const [hex, setHex] = useState('#0ea5e9')
  const rgb = useMemo(() => hexToRgb(hex), [hex])
  const [r, setR] = useState('14'); const [g, setG] = useState('165'); const [b, setB] = useState('233')
  const fromRgb = () => setHex(rgbToHex({ r: +r, g: +g, b: +b }))
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>颜色 HEX ↔ RGB</Text>
      <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginTop: '12rpx' }}>
        <View style={{ width: '80rpx', height: '80rpx', borderRadius: '20rpx', background: hex, border: '1rpx solid var(--border)' }} />
        <Input value={hex} onInput={(e) => setHex((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <View className='detail__btn detail__btn--primary' style={{ flex: 'none', padding: '16rpx 24rpx' }} onClick={() => copy(hex)}>复制 HEX</View>
      </View>
      <View style={{ display: 'flex', gap: '12rpx', alignItems: 'center', marginTop: '12rpx' }}>
        <Input type='number' value={r} onInput={(e) => setR((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <Input type='number' value={g} onInput={(e) => setG((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <Input type='number' value={b} onInput={(e) => setB((e.detail as any).value)}
          style={{ flex: 1, height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }} />
        <View className='detail__btn detail__btn--primary' style={{ flex: 'none', padding: '16rpx 24rpx' }} onClick={fromRgb}>→ HEX</View>
      </View>
      {rgb && (
        <View style={{ marginTop: '12rpx', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
          <Text>rgb({rgb.r}, {rgb.g}, {rgb.b})</Text>
        </View>
      )}
    </View>
  )
}

function HashTool() {
  const [text, setText] = useState('DevBench')
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>字符串 Hash</Text>
      <Textarea value={text} onInput={(e) => setText((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '16rpx' }} />
      <View style={{ marginTop: '16rpx', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
        <Text>DJB2: <Text style={{ color: 'var(--brand)' }}>{djb2(text)}</Text></Text>
      </View>
      <View style={{ marginTop: '12rpx', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
        <Text>CRC32: <Text style={{ color: 'var(--brand)' }}>{crc32(text)}</Text></Text>
      </View>
      <View style={{ display: 'flex', gap: '12rpx', marginTop: '12rpx' }}>
        <View className='detail__btn detail__btn--ghost' onClick={() => copy(djb2(text))}>复制 DJB2</View>
        <View className='detail__btn detail__btn--ghost' onClick={() => copy(crc32(text))}>复制 CRC32</View>
      </View>
    </View>
  )
}

function DiffTool() {
  const [a, setA] = useState('function hello(name) {\n  console.log(`Hi ${name}`);\n}')
  const [b, setB] = useState('function hello(name) {\n  console.log(`Hello, ${name}!`);\n}')
  const diff = useMemo(() => diffText(a, b), [a, b])
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>文本 Diff</Text>
      <View style={{ marginBottom: '12rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>原文 A</Text>
        <Textarea value={a} onInput={(e) => setA((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '8rpx' }} />
      </View>
      <View style={{ marginBottom: '12rpx' }}>
        <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>新版 B</Text>
        <Textarea value={b} onInput={(e) => setB((e.detail as any).value)} autoHeight style={{ ...inputStyle, marginTop: '8rpx' }} />
      </View>
      <View style={{ position: 'relative', marginTop: '16rpx' }}>
        <View style={outputStyle}>
          {diff.map((d, i) => (
            <View key={i}>
              {d.type === 'eq' && <Text style={{ color: '#cbd5e1' }}>{d.text}</Text>}
              {d.type === 'add' && <Text style={{ color: '#4ade80', background: 'rgba(34, 197, 94, 0.2)' }}>{d.text}</Text>}
              {d.type === 'del' && <Text style={{ color: '#f87171', background: 'rgba(239, 68, 68, 0.2)', textDecoration: 'line-through' }}>{d.text}</Text>}
            </View>
          ))}
        </View>
        <View style={{ position: 'absolute', top: '16rpx', right: '16rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'rgba(255,255,255,0.15)', color: 'white', fontSize: '22rpx' }}
          onClick={() => copy(diff.map((d) => (d.type === 'eq' ? ' ' : d.type === 'add' ? '+ ' : '- ') + d.text).join('\n'))}>复制</View>
      </View>
    </View>
  )
}

function CronTool() {
  const [expr, setExpr] = useState('*/5 * * * *')
  const res = useMemo(() => describeCron(expr), [expr])
  return (
    <View style={panelStyle}>
      <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>Cron 表达式解析</Text>
      <Input value={expr} onInput={(e) => setExpr((e.detail as any).value)}
        style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '12rpx', color: 'var(--text-primary)' }} />
      <View style={{ marginTop: '12rpx', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', fontSize: '22rpx', color: 'var(--text-muted)' }}>
        {res.ok ? <Text>{res.description}</Text> : <Text style={{ color: 'var(--danger)' }}>{res.error}</Text>}
      </View>
      {res.ok && (
        <View style={{ marginTop: '12rpx' }}>
          <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>未来 5 次触发:</Text>
          {res.nextRuns?.map((d) => (
            <View key={d} style={{ fontSize: '24rpx', color: 'var(--brand)', padding: '4rpx 0', fontFamily: 'monospace' }}>
              <Text>🕐 {d}</Text>
            </View>
          ))}
        </View>
      )}
      <View style={{ marginTop: '12rpx' }}>
        {['*/5 * * * *', '0 9 * * *', '0 0 * * 0', '0 0 1 * *'].map((c) => (
          <View key={c}
            style={{ display: 'inline-block', marginRight: '8rpx', marginTop: '8rpx', padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'var(--bg-tertiary)', fontSize: '24rpx', color: 'var(--text-secondary)' }}
            onClick={() => setExpr(c)}>
            <Text>{c}</Text>
          </View>
        ))}
      </View>
    </View>
  )
}
