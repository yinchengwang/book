import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo } from 'react'
import { Card } from '@/components/common/Card'
import { ProgressBar } from '@/components/common/ProgressBar'
import { useSettingsStore } from '@/stores/settings-store'
import { useTodosStore, PriorityMap } from '@/stores/todos-store'
import { useTechNotesStore, TechCategoryMap } from '@/stores/tech-notes-store'
import { useReadingStore } from '@/stores/reading-store'
import { useInsightsStore } from '@/stores/insights-store'
import { MoodEmojiMap, useMoodStore } from '@/stores/mood-store'
import { useFitnessStore } from '@/stores/fitness-store'
import { formatRelative, todayStr, weekRange } from '@/utils/date'
import { percent, duration } from '@/utils/format'

const SHORTCUTS = [
  { emoji: '📚', label: '技术笔记', path: '/pages/tech/notes/index' },
  { emoji: '📝', label: '代码片段', path: '/pages/tech/snippets/index' },
  { emoji: '🎯', label: '面试题', path: '/pages/tech/interview/index' },
  { emoji: '🔖', label: '资源收藏', path: '/pages/tech/resources/index' },
  { emoji: '💡', label: '闪念', path: '/pages/insights/index' },
  { emoji: '📅', label: '日程', path: '/pages/life/schedule/index' },
  { emoji: '💪', label: '健身', path: '/pages/life/fitness/index' },
  { emoji: '🚀', label: '项目集', path: '/pages/projects/index' }
]

export default function Dashboard() {
  const profile = useSettingsStore((s) => s.profile)
  const todos = useTodosStore((s) => s.todos)
  const toggleTodo = useTodosStore((s) => s.toggle)
  const notes = useTechNotesStore((s) => s.notes)
  const insights = useInsightsStore((s) => s.insights)
  const readingList = useReadingStore((s) => s.list)
  const fitness = useFitnessStore((s) => s.records)
  const upsertMood = useMoodStore((s) => s.upsertToday)
  const moodEntries = useMoodStore((s) => s.entries)

  const today = todayStr()
  const todoStats = useMemo(() => {
    const open = todos.filter((t) => !t.done).length
    const done = todos.filter((t) => t.done).length
    return { open, done, total: todos.length }
  }, [todos])

  const weekFitness = useMemo(() => {
    const { start, end } = weekRange()
    const inWeek = fitness.filter((r) => r.date >= start && r.date <= end)
    return {
      totalMin: inWeek.reduce((acc, r) => acc + r.durationMin, 0),
      days: new Set(inWeek.map((r) => r.date)).size
    }
  }, [fitness])

  const readingCurrent = useMemo(() => readingList.filter((r) => r.status === 'reading'), [readingList])
  const todaysMood = useMemo(() => moodEntries.find((m) => m.date === today), [moodEntries, today])

  const setMood = (level: 1 | 2 | 3 | 4 | 5) => {
    upsertMood({ level, emoji: MoodEmojiMap[level].emoji, tags: [] })
  }

  const goto = (url: string) => Taro.navigateTo({ url })

  return (
    <View className='page-container'>
      <View style={{
        borderRadius: '32rpx', padding: '32rpx 24rpx', marginBottom: '24rpx',
        background: 'linear-gradient(135deg, var(--brand) 0%, var(--accent) 100%)',
        color: 'white', boxShadow: 'var(--shadow-md)'
      }}>
        <Text style={{ fontSize: '28rpx', opacity: 0.85 }}>Hi, 程序员</Text>
        <View style={{ fontSize: '44rpx', fontWeight: 700, marginTop: '4rpx' }}>{profile.nickname}</View>
        <View style={{ marginTop: '16rpx', fontSize: '24rpx', opacity: 0.9, lineHeight: 1.5 }}>"{profile.motto ?? '保持好奇,持续构建。'}"</View>
        <View style={{ display: 'flex', gap: '16rpx', marginTop: '24rpx' }}>
          {[
            { v: todoStats.open, l: '待办' },
            { v: notes.length, l: '笔记' },
            { v: readingCurrent.length, l: '在读书' },
            { v: weekFitness.days, l: '本周运动' }
          ].map((s, i) => (
            <View key={i} style={{ flex: 1, background: 'rgba(255,255,255,0.18)', padding: '16rpx', borderRadius: '16rpx' }}>
              <View style={{ fontSize: '36rpx', fontWeight: 700, lineHeight: 1.1 }}>{s.v}</View>
              <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>{s.l}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16rpx', marginBottom: '24rpx' }}>
        {SHORTCUTS.map((s) => (
          <View key={s.path}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16rpx 0', background: 'var(--bg-secondary)', borderRadius: '16rpx', boxShadow: 'var(--shadow-sm)' }}
            onClick={() => goto(s.path)}>
            <View style={{ fontSize: '44rpx', marginBottom: '8rpx' }}>{s.emoji}</View>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-secondary)' }}>{s.label}</Text>
          </View>
        ))}
      </View>

      <Card>
        <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8rpx 0' }}>
          <Text style={{ fontSize: '32rpx', fontWeight: 700 }}>今天的心情</Text>
          {todaysMood && <Text style={{ color: 'var(--text-muted)', fontSize: '26rpx' }}>{MoodEmojiMap[todaysMood.level].label}</Text>}
        </View>
        <View style={{ display: 'flex', gap: '16rpx', margin: '16rpx 0' }}>
          {[1, 2, 3, 4, 5].map((lv) => {
            const level = lv as 1 | 2 | 3 | 4 | 5
            const active = todaysMood?.level === level
            return (
              <View key={lv}
                style={{
                  flex: 1, textAlign: 'center', padding: '24rpx 0', borderRadius: '16rpx',
                  background: active ? 'var(--brand-soft)' : 'var(--bg-tertiary)',
                  border: active ? '2rpx solid var(--brand)' : '2rpx solid transparent',
                  fontSize: '36rpx'
                }}
                onClick={() => setMood(level)}>
                {MoodEmojiMap[level].emoji}
              </View>
            )
          })}
        </View>
        {todaysMood?.note && <Text style={{ fontSize: '26rpx', color: 'var(--text-secondary)' }}>{todaysMood.note}</Text>}
      </Card>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' />
          <Text className='section-title__text'>今日待办</Text>
        </View>
        <Text className='section-title__extra' onClick={() => goto('/pages/dashboard/index')}>查看全部 ›</Text>
      </View>
      <Card>
        {todos.filter((t) => !t.done).slice(0, 4).map((t) => (
          <View key={t.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16rpx 0' }} onClick={() => toggleTodo(t.id)}>
            <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
              <Text style={{ fontSize: '36rpx' }}>○</Text>
              <Text>{t.title}</Text>
            </View>
            <View style={{ padding: '6rpx 16rpx', borderRadius: '999rpx', fontSize: '22rpx', background: `${PriorityMap[t.priority].color}20`, color: PriorityMap[t.priority].color }}>
              <Text>{PriorityMap[t.priority].label}</Text>
            </View>
          </View>
        ))}
        {todos.filter((t) => !t.done).length === 0 && (
          <View style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '32rpx 0', color: 'var(--text-muted)', fontSize: '24rpx' }}>
            ✨ 没有待办,享受片刻宁静
          </View>
        )}
        {todos.length > 0 && <ProgressBar percent={percent(todoStats.done, todoStats.total)} color='var(--success)' showText size='thin' />}
      </Card>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' />
          <Text className='section-title__text'>在读书目</Text>
        </View>
        <Text className='section-title__extra' onClick={() => goto('/pages/life/reading/index')}>详情 ›</Text>
      </View>
      <Card>
        {readingCurrent.length === 0 && (
          <View style={{ padding: '32rpx 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '24rpx' }}>📚 还没有在读的书,去添加一本吧</View>
        )}
        {readingCurrent.map((r) => {
          const p = percent(r.currentPage, r.totalPages || r.currentPage || 1)
          return (
            <View key={r.id}>
              <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8rpx 0' }} onClick={() => goto('/pages/life/reading/index')}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: '28rpx' }}>{r.title}</Text>
                  <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>{r.author ?? '佚名'}</Text>
                </View>
                <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)', minWidth: '80rpx', textAlign: 'right' }}>{p}%</Text>
              </View>
              <ProgressBar percent={p} size='thin' />
            </View>
          )
        })}
      </Card>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' />
          <Text className='section-title__text'>最近笔记</Text>
        </View>
        <Text className='section-title__extra' onClick={() => goto('/pages/tech/notes/index')}>更多 ›</Text>
      </View>
      <Card>
        {notes.slice(0, 3).map((n) => (
          <View key={n.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '16rpx 0' }} onClick={() => goto(`/pages/tech/notes/index?id=${n.id}`)}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: '28rpx' }}>{n.title}</Text>
              <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>
                {TechCategoryMap[n.category].emoji} {TechCategoryMap[n.category].label} · {formatRelative(n.updatedAt)}
              </Text>
            </View>
          </View>
        ))}
        {notes.length === 0 && (
          <View style={{ padding: '32rpx 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '24rpx' }}>还没有笔记,先把灵感记下来</View>
        )}
      </Card>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' style={{ background: 'var(--success)' }} />
          <Text className='section-title__text'>本周运动</Text>
        </View>
        <Text className='section-title__extra' onClick={() => goto('/pages/life/fitness/index')}>记录 ›</Text>
      </View>
      <Card>
        <View style={{ display: 'flex', gap: '16rpx', marginBottom: '16rpx' }}>
          <View style={{ flex: 1, background: 'var(--bg-tertiary)', padding: '16rpx', borderRadius: '16rpx' }}>
            <View style={{ fontSize: '36rpx', fontWeight: 700 }}>{weekFitness.totalMin}</View>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-secondary)' }}>运动分钟</Text>
          </View>
          <View style={{ flex: 1, background: 'var(--bg-tertiary)', padding: '16rpx', borderRadius: '16rpx' }}>
            <View style={{ fontSize: '36rpx', fontWeight: 700 }}>{weekFitness.days}/7</View>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-secondary)' }}>运动天数</Text>
          </View>
        </View>
        {fitness.slice(0, 3).map((r) => (
          <View key={r.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8rpx 0' }}>
            <View style={{ flex: 1 }}>
              <Text>{r.name}</Text>
              <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>{r.date}</Text>
            </View>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>{duration(r.durationMin)}</Text>
          </View>
        ))}
        {fitness.length === 0 && (
          <View style={{ padding: '32rpx 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '24rpx' }}>本周还没有运动,出门走走吧</View>
        )}
      </Card>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' style={{ background: 'var(--accent)' }} />
          <Text className='section-title__text'>最新闪念</Text>
        </View>
        <Text className='section-title__extra' onClick={() => goto('/pages/insights/index')}>全部 ›</Text>
      </View>
      <Card variant='gradient'>
        {insights.length === 0 ? (
          <Text style={{ color: 'white', opacity: 0.85 }}>点击"闪念"记录一个灵感</Text>
        ) : (
          <View>
            <Text style={{ color: 'white', fontSize: '30rpx', lineHeight: 1.5 }}>{insights[0].content}</Text>
            <Text style={{ color: 'white', opacity: 0.7, fontSize: '22rpx', marginTop: '8rpx' }}>{formatRelative(insights[0].createdAt)}</Text>
          </View>
        )}
      </Card>
    </View>
  )
}
