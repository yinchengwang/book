export default definePageConfig({
  navigationBarTitleText: 'DevBench · 工作台',
  enablePullDownRefresh: false
})
