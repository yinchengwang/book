import { View, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useSettingsStore } from '@/stores/settings-store'
import { useTechNotesStore } from '@/stores/tech-notes-store'
import { useSnippetsStore } from '@/stores/snippets-store'
import { useInterviewStore } from '@/stores/interview-store'
import { useResourcesStore } from '@/stores/resources-store'
import { useReadingStore } from '@/stores/reading-store'
import { useFitnessStore } from '@/stores/fitness-store'
import { useMoodStore } from '@/stores/mood-store'
import { useScheduleStore } from '@/stores/schedule-store'
import { useProjectsStore } from '@/stores/projects-store'
import { useInsightsStore } from '@/stores/insights-store'
import { Storage } from '@/utils/storage'
import { showPrompt } from '@/utils/dialog'
import { clearAllLocalData } from '@/stores/_bootstrap'

export default function ProfilePage() {
  const settings = useSettingsStore()
  const notesCount = useTechNotesStore((s) => s.notes.length)
  const snippetsCount = useSnippetsStore((s) => s.snippets.length)
  const interviewCount = useInterviewStore((s) => s.questions.length)
  const resourcesCount = useResourcesStore((s) => s.resources.length)
  const readingCount = useReadingStore((s) => s.list.length)
  const fitnessCount = useFitnessStore((s) => s.records.length)
  const moodCount = useMoodStore((s) => s.entries.length)
  const scheduleCount = useScheduleStore((s) => s.events.length)
  const projectsCount = useProjectsStore((s) => s.projects.length)
  const insightsCount = useInsightsStore((s) => s.insights.length)

  const [showProfileEdit, setShowProfileEdit] = useState(false)
  const [p_nick, setPNick] = useState(settings.profile.nickname)
  const [p_role, setPRole] = useState(settings.profile.role)
  const [p_bio, setPBio] = useState(settings.profile.bio ?? '')
  const [p_motto, setPMotto] = useState(settings.profile.motto ?? '')

  const total = useMemo(() =>
    notesCount + snippetsCount + interviewCount + resourcesCount +
    readingCount + fitnessCount + moodCount + scheduleCount + projectsCount + insightsCount,
    [notesCount, snippetsCount, interviewCount, resourcesCount, readingCount, fitnessCount, moodCount, scheduleCount, projectsCount, insightsCount])

  const onExport = () => {
    const data = Storage.exportAll()
    Taro.setClipboardData({ data, success: () => Taro.showModal({ title: '导出成功', content: '已复制到剪贴板', showCancel: false }) })
  }
  const onImport = () => {
    showPrompt({
      title: '导入备份',
      placeholderText: '粘贴此前导出的 JSON'
    }).then((text) => {
      if (!text) return
      const r = Storage.importAll(text, 'merge')
      if (r.ok) {
        Taro.showModal({ title: `导入 ${r.count} 项`, content: '请重启小程序以使全部 store 生效', showCancel: false })
      } else {
        Taro.showToast({ title: r.error ?? '导入失败', icon: 'none' })
      }
    })
  }
  const onClear = () => {
    Taro.showModal({
      title: '清空全部?', content: '此操作不可恢复',
      success: (m) => { if (m.confirm) { clearAllLocalData(); Taro.showToast({ title: '已清空', icon: 'success' }) } }
    })
  }
  const onAbout = () => Taro.showModal({ title: 'DevBench', content: '版本 1.0.0\nTaro 3.6 + React 18 + TypeScript + Zustand\n本地优先 · 离线可用', showCancel: false })
  const submitProfile = () => {
    if (!p_nick.trim()) return Taro.showToast({ title: '昵称不能为空', icon: 'none' })
    settings.updateProfile({ nickname: p_nick.trim(), role: p_role.trim(), bio: p_bio.trim() || undefined, motto: p_motto.trim() || undefined })
    setShowProfileEdit(false)
    Taro.showToast({ title: '已保存', icon: 'success' })
  }

  const rowStyle: React.CSSProperties = {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '24rpx', borderBottom: '1rpx solid var(--divider)'
  }
  const sectionStyle: React.CSSProperties = {
    background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '8rpx 0', marginBottom: '16rpx',
    boxShadow: 'var(--shadow-sm)'
  }

  return (
    <View className='page-container'>
      <View style={{ background: 'linear-gradient(135deg, var(--brand) 0%, var(--accent) 100%)', color: 'white', borderRadius: '32rpx', padding: '40rpx 24rpx 32rpx', marginBottom: '24rpx', boxShadow: 'var(--shadow-md)', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
        <View style={{ width: '140rpx', height: '140rpx', borderRadius: '50%', background: 'rgba(255,255,255,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '70rpx', marginBottom: '16rpx' }}>👨‍💻</View>
        <View style={{ fontSize: '40rpx', fontWeight: 700 }}>{settings.profile.nickname}</View>
        <View style={{ fontSize: '24rpx', opacity: 0.9, marginTop: '4rpx' }}>{settings.profile.role}</View>
        {settings.profile.motto && <View style={{ marginTop: '16rpx', fontSize: '22rpx', padding: '8rpx 20rpx', background: 'rgba(255,255,255,0.18)', borderRadius: '999rpx', maxWidth: '90%' }}>"{settings.profile.motto}"</View>}
        <View style={{ marginTop: '24rpx', padding: '8rpx 24rpx', background: 'rgba(255,255,255,0.25)', borderRadius: '999rpx', fontSize: '24rpx' }}
          onClick={() => { setPNick(settings.profile.nickname); setPRole(settings.profile.role); setPBio(settings.profile.bio ?? ''); setPMotto(settings.profile.motto ?? ''); setShowProfileEdit(true) }}>
          <Text>✏️ 编辑资料</Text>
        </View>
      </View>

      <Text style={{ padding: '0 0 16rpx', fontSize: '24rpx', color: 'var(--text-muted)' }}>数据总览</Text>
      <View style={sectionStyle}>
        <View style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16rpx', padding: '16rpx' }}>
          {[{ v: total, l: '累计' }, { v: notesCount + snippetsCount + interviewCount, l: '技术' }, { v: readingCount + moodCount + fitnessCount, l: '生活' }].map((s, i) => (
            <View key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16rpx 0', background: 'var(--bg-tertiary)', borderRadius: '16rpx' }}>
              <View style={{ fontSize: '36rpx', fontWeight: 700, color: 'var(--text-primary)' }}>{s.v}</View>
              <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)', marginTop: '4rpx' }}>{s.l}</Text>
            </View>
          ))}
        </View>
      </View>

      <Text style={{ padding: '16rpx 0 8rpx', fontSize: '24rpx', color: 'var(--text-muted)' }}>外观</Text>
      <View style={sectionStyle}>
        <View style={rowStyle}>
          <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
            <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--brand-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx', color: 'var(--brand)' }}>🎨</View>
            <Text style={{ fontSize: '28rpx' }}>主题</Text>
          </View>
          <View style={{ display: 'flex', gap: '4rpx', padding: '4rpx', background: 'var(--bg-tertiary)', borderRadius: '999rpx' }}>
            {(['light', 'dark', 'auto'] as const).map((m) => (
              <View key={m}
                style={{ padding: '6rpx 18rpx', borderRadius: '999rpx', fontSize: '22rpx', color: settings.theme === m ? 'var(--text-primary)' : 'var(--text-secondary)', background: settings.theme === m ? 'var(--bg-secondary)' : 'transparent', fontWeight: settings.theme === m ? 600 : 400, boxShadow: settings.theme === m ? 'var(--shadow-sm)' : 'none' }}
                onClick={() => settings.setTheme(m)}>
                {m === 'light' ? '亮色' : m === 'dark' ? '暗色' : '跟随'}
              </View>
            ))}
          </View>
        </View>
        <View style={rowStyle}>
          <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
            <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx', color: 'var(--accent)' }}>🎯</View>
            <Text style={{ fontSize: '28rpx' }}>主色</Text>
          </View>
          <View style={{ display: 'flex', gap: '8rpx' }}>
            {['#0ea5e9', '#8b5cf6', '#22c55e', '#ec4899', '#f59e0b'].map((c) => (
              <View key={c}
                style={{ width: '40rpx', height: '40rpx', borderRadius: '50%', background: c, border: settings.primaryColor === c ? '4rpx solid white' : '2rpx solid transparent', boxShadow: settings.primaryColor === c ? `0 0 0 2rpx ${c}` : 'none' }}
                onClick={() => settings.setPrimaryColor(c)} />
            ))}
          </View>
        </View>
      </View>

      <Text style={{ padding: '16rpx 0 8rpx', fontSize: '24rpx', color: 'var(--text-muted)' }}>通知</Text>
      <View style={sectionStyle}>
        <View style={rowStyle}>
          <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
            <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--warning-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx', color: 'var(--warning)' }}>🔔</View>
            <Text style={{ fontSize: '28rpx' }}>每日提醒</Text>
          </View>
          <View style={{ width: '80rpx', height: '40rpx', borderRadius: '20rpx', background: settings.enableDailyReminder ? 'var(--brand)' : 'var(--bg-tertiary)', display: 'flex', alignItems: 'center', padding: '0 4rpx' }}
            onClick={() => settings.setEnableDailyReminder(!settings.enableDailyReminder)}>
            <View style={{ width: '32rpx', height: '32rpx', borderRadius: '50%', background: 'white', transform: `translateX(${settings.enableDailyReminder ? '40rpx' : '0'})`, transition: 'all 0.2s' }} />
          </View>
        </View>
        {settings.enableDailyReminder && (
          <View style={rowStyle}>
            <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
              <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx' }}>🕘</View>
              <Text style={{ fontSize: '28rpx' }}>提醒时间</Text>
            </View>
            <Input value={settings.reminderTime} onInput={(e) => settings.setReminderTime((e.detail as any).value)}
              style={{ width: '120rpx', textAlign: 'right', fontSize: '26rpx', color: 'var(--text-primary)' }} />
          </View>
        )}
      </View>

      <Text style={{ padding: '16rpx 0 8rpx', fontSize: '24rpx', color: 'var(--text-muted)' }}>数据</Text>
      <View style={sectionStyle}>
        {[
          { icon: '📤', bg: 'var(--success-soft)', color: 'var(--success)', label: '导出 / 备份', onTap: onExport },
          { icon: '📥', bg: 'var(--success-soft)', color: 'var(--success)', label: '从备份恢复', onTap: onImport },
          { icon: '🗑', bg: 'var(--danger-soft)', color: 'var(--danger)', label: '清空全部数据', danger: true, onTap: onClear }
        ].map((r, i) => (
          <View key={i} style={rowStyle} onClick={r.onTap}>
            <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
              <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: r.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx', color: r.color }}>{r.icon}</View>
              <Text style={{ fontSize: '28rpx', color: r.danger ? 'var(--danger)' : 'var(--text-primary)' }}>{r.label}</Text>
            </View>
            <Text style={{ color: 'var(--text-muted)' }}>›</Text>
          </View>
        ))}
      </View>

      <Text style={{ padding: '16rpx 0 8rpx', fontSize: '24rpx', color: 'var(--text-muted)' }}>其他</Text>
      <View style={sectionStyle}>
        <View style={rowStyle} onClick={onAbout}>
          <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
            <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx' }}>ℹ️</View>
            <Text style={{ fontSize: '28rpx' }}>关于 DevBench</Text>
          </View>
          <Text style={{ color: 'var(--text-muted)' }}>v1.0.0 ›</Text>
        </View>
        <View style={rowStyle} onClick={() => settings.resetSettings()}>
          <View style={{ display: 'flex', alignItems: 'center', gap: '16rpx' }}>
            <View style={{ width: '56rpx', height: '56rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx' }}>♻️</View>
            <Text style={{ fontSize: '28rpx' }}>重置设置</Text>
          </View>
          <Text style={{ color: 'var(--text-muted)' }}>›</Text>
        </View>
      </View>

      <View style={{ padding: '32rpx 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '24rpx' }}>
        <Text>本地优先 · 离线可用 · 数据归你所有</Text>
      </View>

      {showProfileEdit && (
        <View className='modal-mask' onClick={() => setShowProfileEdit(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>编辑个人资料</View>
            {([
              { label: '昵称', value: p_nick, onChange: setPNick },
              { label: '角色', value: p_role, onChange: setPRole },
              { label: '个人简介', value: p_bio, onChange: setPBio },
              { label: '个人签名', value: p_motto, onChange: setPMotto }
            ] as const).map((f, i) => (
              <View key={i} style={{ marginBottom: '16rpx' }}>
                <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>{f.label}</Text>
                <Input value={f.value} onInput={(e) => f.onChange((e.detail as any).value)}
                  style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
              </View>
            ))}
            <View style={{ display: 'flex', gap: '16rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowProfileEdit(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submitProfile}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
