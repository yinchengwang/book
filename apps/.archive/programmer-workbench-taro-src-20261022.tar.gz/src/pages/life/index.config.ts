export default definePageConfig({ navigationBarTitleText: '生活', enablePullDownRefresh: true })
