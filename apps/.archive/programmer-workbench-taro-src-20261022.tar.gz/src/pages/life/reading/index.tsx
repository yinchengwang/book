import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useReadingStore } from '@/stores/reading-store'
import { Card } from '@/components/common/Card'
import { Empty } from '@/components/common/Empty'
import { ProgressBar } from '@/components/common/ProgressBar'
import { percent } from '@/utils/format'
import { showPrompt } from '@/utils/dialog'
import type { ReadingItem } from '@/types'

const TABS: Array<{ key: ReadingItem['status']; label: string }> = [
  { key: 'reading', label: '在读' },
  { key: 'wishlist', label: '想读' },
  { key: 'finished', label: '已读' },
  { key: 'paused', label: '暂缓' }
]
const COVERS = ['📕', '📗', '📘', '📙', '📓', '📔', '📒', '📚']

export default function ReadingPage() {
  const list = useReadingStore((s) => s.list)
  const add = useReadingStore((s) => s.add)
  const update = useReadingStore((s) => s.update)
  const setPage = useReadingStore((s) => s.setPage)
  const setStatus = useReadingStore((s) => s.setStatus)
  const remove = useReadingStore((s) => s.remove)
  const [tab, setTab] = useState<ReadingItem['status']>('reading')
  const [editing, setEditing] = useState<ReadingItem | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [m_title, setMTitle] = useState('')
  const [m_author, setMAuthor] = useState('')
  const [m_total, setMTotal] = useState('')
  const [m_rating, setMRating] = useState(0)

  const filtered = useMemo(() => list.filter((r) => r.status === tab), [list, tab])

  const onCreate = () => {
    setEditing(null)
    setMTitle(''); setMAuthor(''); setMTotal(''); setMRating(0)
    setShowModal(true)
  }
  const onEdit = (item: ReadingItem) => {
    setEditing(item)
    setMTitle(item.title); setMAuthor(item.author ?? '')
    setMTotal(item.totalPages ? String(item.totalPages) : ''); setMRating(item.rating ?? 0)
    setShowModal(true)
  }
  const submit = () => {
    if (!m_title.trim()) return Taro.showToast({ title: '请输入书名', icon: 'none' })
    const total = parseInt(m_total, 10) || undefined
    if (editing) update(editing.id, { title: m_title.trim(), author: m_author.trim() || undefined, totalPages: total, rating: m_rating || undefined })
    else add({ title: m_title.trim(), author: m_author.trim() || undefined, totalPages: total, status: tab, rating: m_rating || undefined })
    setShowModal(false)
    Taro.showToast({ title: '已保存', icon: 'success' })
  }
  const onUpdateProgress = (item: ReadingItem) => {
    showPrompt({
      title: '更新进度',
      placeholderText: `当前 ${item.currentPage} / ${item.totalPages ?? '?'} 页,输入新页码`
    }).then((text) => {
      if (!text) return
      const p = parseInt(text, 10)
      if (!Number.isNaN(p)) setPage(item.id, p)
    })
  }
  const onLongPress = (item: ReadingItem) => {
    Taro.showActionSheet({
      itemList: ['编辑', '更新进度', '移到想读', '移到已读', '删除'],
      success: (r) => {
        if (r.tapIndex === 0) onEdit(item)
        else if (r.tapIndex === 1) onUpdateProgress(item)
        else if (r.tapIndex === 2) setStatus(item.id, 'wishlist')
        else if (r.tapIndex === 3) setStatus(item.id, 'finished')
        else if (r.tapIndex === 4) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(item.id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ display: 'flex', background: 'var(--bg-secondary)', borderRadius: '999rpx', padding: '6rpx', marginBottom: '24rpx' }}>
        {TABS.map((s) => (
          <View key={s.key}
            style={{ flex: 1, textAlign: 'center', padding: '12rpx 0', fontSize: '26rpx', color: tab === s.key ? 'white' : 'var(--text-secondary)', background: tab === s.key ? 'var(--brand)' : 'transparent', borderRadius: '999rpx', fontWeight: tab === s.key ? 600 : 400 }}
            onClick={() => setTab(s.key)}>
            {s.label}
          </View>
        ))}
      </View>
      {filtered.length === 0 && <Empty icon='📚' title='还没有书目' actionText='添加书目' onAction={onCreate} />}
      {filtered.map((item, idx) => {
        const p = percent(item.currentPage, item.totalPages || item.currentPage || 1)
        return (
          <View key={item.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)', display: 'flex', gap: '24rpx' }}
            onClick={() => onUpdateProgress(item)} onLongPress={() => onLongPress(item)}>
            <View style={{ width: '120rpx', height: '168rpx', borderRadius: '12rpx', background: 'linear-gradient(135deg, var(--brand) 0%, var(--accent) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '80rpx', flexShrink: 0 }}>
              {COVERS[idx % COVERS.length]}
            </View>
            <View style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minWidth: 0 }}>
              <View>
                <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)' }}>{item.title}</Text>
                <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>{item.author ?? '佚名'}</Text>
              </View>
              <View>
                {(item.totalPages ?? 0) > 0 && <ProgressBar percent={p} color={p === 100 ? 'var(--success)' : 'var(--brand)'} size='thin' />}
                <View style={{ display: 'flex', justifyContent: 'space-between', fontSize: '22rpx', color: 'var(--text-muted)', marginTop: '8rpx' }}>
                  <Text>{item.currentPage}/{item.totalPages ?? '?'} 页</Text>
                  {item.rating ? <Text style={{ color: 'var(--warning)' }}>{'★'.repeat(item.rating)}</Text> : null}
                </View>
              </View>
            </View>
          </View>
        )
      })}
      <View className='fab' onClick={onCreate}>+</View>

      {showModal && (
        <View className='modal-mask' onClick={() => setShowModal(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>{editing ? '编辑书目' : '添加书目'}</View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>书名</Text>
              <Input value={m_title} onInput={(e) => setMTitle((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>作者</Text>
              <Input value={m_author} onInput={(e) => setMAuthor((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>总页数</Text>
              <Input value={m_total} type='number' onInput={(e) => setMTotal((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '24rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>评分</Text>
              <View style={{ display: 'flex', gap: '12rpx', fontSize: '44rpx', marginTop: '4rpx' }}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <Text key={n} style={{ color: n <= m_rating ? 'var(--warning)' : 'var(--text-muted)' }} onClick={() => setMRating(n)}>
                    {n <= m_rating ? '★' : '☆'}
                  </Text>
                ))}
              </View>
            </View>
            <View style={{ display: 'flex', gap: '16rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowModal(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submit}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
