export default definePageConfig({ navigationBarTitleText: '读书', enablePullDownRefresh: true })
