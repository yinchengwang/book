import { View, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useFitnessStore } from '@/stores/fitness-store'
import { Empty } from '@/components/common/Empty'
import { duration } from '@/utils/format'
import { weekRange } from '@/utils/date'
import type { FitnessType } from '@/types'

const TYPE_META: Record<FitnessType, { emoji: string; label: string }> = {
  cardio:       { emoji: '🏃', label: '有氧' },
  strength:     { emoji: '🏋️', label: '力量' },
  flexibility:  { emoji: '🧘', label: '柔韧' },
  sports:       { emoji: '⚽', label: '球类' },
  other:        { emoji: '🎯', label: '其他' }
}

export default function FitnessPage() {
  const records = useFitnessStore((s) => s.records)
  const add = useFitnessStore((s) => s.add)
  const remove = useFitnessStore((s) => s.remove)
  const [showModal, setShowModal] = useState(false)
  const [m_date, setMDate] = useState(() => new Date().toISOString().slice(0, 10))
  const [m_type, setMType] = useState<FitnessType>('cardio')
  const [m_name, setMName] = useState('')
  const [m_duration, setMDuration] = useState('')
  const [m_calories, setMCalories] = useState('')

  const sorted = useMemo(() => [...records].sort((a, b) =>
    b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)
  ), [records])

  const weekStats = useMemo(() => {
    const { start, end } = weekRange()
    const thisWeek = records.filter((r) => r.date >= start && r.date <= end)
    return {
      total: thisWeek.reduce((acc, r) => acc + r.durationMin, 0),
      cals: thisWeek.reduce((acc, r) => acc + (r.calories ?? 0), 0),
      days: new Set(thisWeek.map((r) => r.date)).size
    }
  }, [records])

  const grouped = useMemo(() => {
    const out: Record<string, typeof records> = {}
    sorted.forEach((r) => {
      const k = r.date.slice(0, 7)
      if (!out[k]) out[k] = []
      out[k].push(r)
    })
    return out
  }, [sorted])

  const submit = () => {
    if (!m_name.trim()) return Taro.showToast({ title: '请填写运动名', icon: 'none' })
    const d = parseInt(m_duration, 10) || 0
    if (d <= 0) return Taro.showToast({ title: '请输入时长', icon: 'none' })
    add({
      date: m_date, type: m_type, name: m_name.trim(), durationMin: d,
      calories: parseInt(m_calories, 10) || undefined
    })
    setShowModal(false)
    setMName(''); setMDuration(''); setMCalories('')
    Taro.showToast({ title: '已记录', icon: 'success' })
  }
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['删除'],
      success: (r) => {
        if (r.tapIndex === 0) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ background: 'linear-gradient(135deg, #22c55e 0%, #0ea5e9 100%)', borderRadius: '32rpx', padding: '32rpx 24rpx', color: 'white', marginBottom: '24rpx', display: 'flex', gap: '24rpx', boxShadow: 'var(--shadow-md)' }}>
        <View style={{ flex: 1 }}>
          <View style={{ fontSize: '56rpx', fontWeight: 700, lineHeight: 1.1 }}>{weekStats.days}</View>
          <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>本周 / 7 天</Text>
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ fontSize: '56rpx', fontWeight: 700, lineHeight: 1.1 }}>{weekStats.total}</View>
          <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>分钟</Text>
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ fontSize: '56rpx', fontWeight: 700, lineHeight: 1.1 }}>{weekStats.cals || '—'}</View>
          <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>千卡</Text>
        </View>
      </View>

      {sorted.length === 0 && <Empty icon='💪' title='还没有记录' actionText='马上记录' onAction={() => setShowModal(true)} />}
      {Object.entries(grouped).map(([month, items]) => (
        <View key={month}>
          <View className='section-title'>
            <View className='section-title__main'>
              <View className='section-title__bar' style={{ background: 'var(--success)' }} />
              <Text className='section-title__text'>{month}</Text>
            </View>
            <Text className='section-title__extra'>{items.length} 次</Text>
          </View>
          {items.map((r) => (
            <View key={r.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)', display: 'flex', alignItems: 'center', gap: '24rpx' }}
              onLongPress={() => onLongPress(r.id)}>
              <View style={{ width: '80rpx', height: '80rpx', borderRadius: '24rpx',
                background: r.type === 'cardio' ? 'var(--success-soft)' : r.type === 'strength' ? 'var(--accent-soft)' : 'var(--brand-soft)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '40rpx', flexShrink: 0 }}>
                {TYPE_META[r.type].emoji}
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={{ fontSize: '30rpx', fontWeight: 700, color: 'var(--text-primary)' }}>{r.name}</Text>
                <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>
                  {r.date} · {TYPE_META[r.type].label}
                  {r.calories ? ` · ${r.calories} 千卡` : ''}
                </Text>
              </View>
              <Text style={{ fontSize: '24rpx', color: 'var(--brand)', fontWeight: 600 }}>{duration(r.durationMin)}</Text>
            </View>
          ))}
        </View>
      ))}

      <View className='fab' onClick={() => setShowModal(true)}>+</View>

      {showModal && (
        <View className='modal-mask' onClick={() => setShowModal(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>记录运动</View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>日期</Text>
              <Input value={m_date} onInput={(e) => setMDate((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>类型</Text>
              <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginTop: '8rpx' }}>
                {Object.entries(TYPE_META).map(([k, v]) => (
                  <View key={k} className={`tag-row__item${m_type === k ? ' tag-row__item--active' : ''}`} onClick={() => setMType(k as FitnessType)}>
                    {v.emoji} {v.label}
                  </View>
                ))}
              </View>
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>项目</Text>
              <Input value={m_name} onInput={(e) => setMName((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ display: 'flex', gap: '16rpx', marginBottom: '24rpx' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>时长(分)</Text>
                <Input type='number' value={m_duration} onInput={(e) => setMDuration((e.detail as any).value)}
                  style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>千卡</Text>
                <Input type='number' value={m_calories} onInput={(e) => setMCalories((e.detail as any).value)}
                  style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
              </View>
            </View>
            <View style={{ display: 'flex', gap: '16rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowModal(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submit}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
