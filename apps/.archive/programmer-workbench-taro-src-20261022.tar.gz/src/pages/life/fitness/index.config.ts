export default definePageConfig({ navigationBarTitleText: '健身', enablePullDownRefresh: true })
