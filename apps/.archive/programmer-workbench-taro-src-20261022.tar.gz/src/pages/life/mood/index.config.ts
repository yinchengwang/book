export default definePageConfig({ navigationBarTitleText: '心情', enablePullDownRefresh: true })
