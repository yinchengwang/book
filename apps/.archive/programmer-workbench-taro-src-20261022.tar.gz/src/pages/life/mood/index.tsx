import { View, Text, Textarea, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useMoodStore, MoodEmojiMap } from '@/stores/mood-store'
import { Empty } from '@/components/common/Empty'
import { formatRelative, todayStr, dateListBetween, daysAgo } from '@/utils/date'
import type { MoodLevel } from '@/types'

const TAGS = ['work', 'code', 'study', 'rest', 'social', 'exercise', 'eat', 'rainy', 'sunny']

export default function MoodPage() {
  const entries = useMoodStore((s) => s.entries)
  const upsertToday = useMoodStore((s) => s.upsertToday)
  const remove = useMoodStore((s) => s.remove)
  const today = todayStr()
  const todayEntry = entries.find((e) => e.date === today)

  const [level, setLevel] = useState<MoodLevel | null>(todayEntry?.level ?? null)
  const [note, setNote] = useState(todayEntry?.note ?? '')
  const [selectedTags, setSelectedTags] = useState<string[]>(todayEntry?.tags ?? [])
  const [customTag, setCustomTag] = useState('')

  const heatmap = useMemo(() => {
    const list = dateListBetween(daysAgo(120), today)
    const map = new Map(entries.map((e) => [e.date, e.level]))
    return list.map((d) => ({ date: d, level: map.get(d) as MoodLevel | undefined }))
  }, [entries, today])

  const onSave = () => {
    if (!level) return Taro.showToast({ title: '请先选择今日心情', icon: 'none' })
    upsertToday({ level, emoji: MoodEmojiMap[level].emoji, tags: selectedTags, note: note.trim() || undefined })
    Taro.showToast({ title: '已记录', icon: 'success' })
  }
  const onLongPressEntry = (id: string) => {
    Taro.showActionSheet({
      itemList: ['删除'],
      success: (r) => {
        if (r.tapIndex === 0) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) })
      }
    })
  }
  const sortedEntries = useMemo(() => [...entries].sort((a, b) => b.date.localeCompare(a.date)), [entries])
  const last7 = useMemo(() => {
    const l7 = heatmap.slice(-7).map((c) => c.level).filter(Boolean) as MoodLevel[]
    if (!l7.length) return { avg: 0, count: 0 }
    return { avg: Number((l7.reduce((a, x) => a + x, 0) / l7.length).toFixed(1)), count: l7.length }
  }, [heatmap])

  return (
    <View className='page-container'>
      <View style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '24rpx', boxShadow: 'var(--shadow-sm)' }}>
        <Text style={{ fontSize: '28rpx', fontWeight: 700 }}>此刻心情如何?</Text>
        <View style={{ display: 'flex', gap: '16rpx', margin: '16rpx 0' }}>
          {([1, 2, 3, 4, 5] as MoodLevel[]).map((lv) => (
            <View key={lv}
              style={{ flex: 1, textAlign: 'center', padding: '24rpx 0', borderRadius: '16rpx', background: level === lv ? 'var(--brand-soft)' : 'var(--bg-tertiary)', border: level === lv ? '2rpx solid var(--brand)' : '2rpx solid transparent', fontSize: '40rpx' }}
              onClick={() => setLevel(lv)}>
              {MoodEmojiMap[lv].emoji}
            </View>
          ))}
        </View>
        <Textarea value={note} onInput={(e) => setNote((e.detail as any).value)} autoHeight
          style={{ width: '100%', padding: '24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', color: 'var(--text-primary)' }}
          placeholder='记录一段今天发生的小事...' />
        <View style={{ display: 'flex', flexWrap: 'wrap', gap: '8rpx', marginTop: '16rpx' }}>
          {TAGS.map((t) => (
            <View key={t} className={`tag-row__item${selectedTags.includes(t) ? ' tag-row__item--active' : ''}`}
              onClick={() => setSelectedTags(selectedTags.includes(t) ? selectedTags.filter((x) => x !== t) : [...selectedTags, t])}>
              {selectedTags.includes(t) ? '✓ ' : ''}{t}
            </View>
          ))}
          <View style={{ display: 'flex', gap: '8rpx', marginTop: '8rpx', width: '100%' }}>
            <Input value={customTag} onInput={(e) => setCustomTag((e.detail as any).value)}
              placeholder='自定义标签'
              style={{ flex: 1, height: '56rpx', padding: '0 16rpx', borderRadius: '999rpx', background: 'var(--bg-tertiary)', fontSize: '24rpx', color: 'var(--text-primary)' }} />
            <View
              style={{ padding: '0 20rpx', height: '56rpx', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--brand)', color: 'white', borderRadius: '999rpx', fontSize: '24rpx' }}
              onClick={() => {
                const t = customTag.trim()
                if (t && !selectedTags.includes(t)) setSelectedTags([...selectedTags, t])
                setCustomTag('')
              }}>+</View>
          </View>
        </View>
        <View style={{ marginTop: '24rpx' }}>
          <View className='detail__btn detail__btn--primary' onClick={onSave}>{todayEntry ? '更新今日' : '记录今日'}</View>
        </View>
        {last7.count > 0 && (
          <Text style={{ marginTop: '16rpx', fontSize: '26rpx', color: 'var(--text-muted)' }}>
            近 7 天情绪均值 {last7.avg} / 5 · 记录 {last7.count} 次
          </Text>
        )}
      </View>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' style={{ background: 'var(--accent)' }} />
          <Text className='section-title__text'>心情热图(近 120 天)</Text>
        </View>
      </View>
      <View style={{ display: 'grid', gridTemplateColumns: 'repeat(15, 1fr)', gap: '4rpx', marginTop: '16rpx', background: 'var(--bg-secondary)', padding: '16rpx', borderRadius: '16rpx' }}>
        {heatmap.map((c) => {
          const color = !c.level
            ? 'var(--bg-tertiary)'
            : `rgba(99, 102, 241, ${0.2 + (c.level / 5) * 0.8})`
          return <View key={c.date} style={{ aspectRatio: '1', borderRadius: '2rpx', background: color }} />
        })}
      </View>

      <View className='section-title'>
        <View className='section-title__main'>
          <View className='section-title__bar' />
          <Text className='section-title__text'>心情日记</Text>
        </View>
      </View>
      {sortedEntries.length === 0 && <Empty icon='💭' title='还没有记录' desc='每天 1 分钟,30 天后回头看看,会很不一样。' />}
      {sortedEntries.map((m) => {
        const info = MoodEmojiMap[m.level]
        return (
          <View key={m.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)' }} onLongPress={() => onLongPressEntry(m.id)}>
            <View style={{ display: 'flex', alignItems: 'center', marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '60rpx', marginRight: '24rpx' }}>{m.emoji}</Text>
              <View>
                <Text style={{ fontSize: '28rpx', fontWeight: 700, color: 'var(--text-primary)' }}>{m.date}</Text>
                <Text style={{ display: 'block', fontSize: '22rpx', color: 'var(--text-muted)' }}>{info.label} · {formatRelative(m.createdAt)}</Text>
              </View>
            </View>
            {m.note && <Text style={{ fontSize: '26rpx', color: 'var(--text-secondary)', padding: '16rpx', background: 'var(--bg-tertiary)', borderRadius: '12rpx', lineHeight: 1.6 }}>{m.note}</Text>}
            {m.tags.length > 0 && (
              <View style={{ display: 'flex', flexWrap: 'wrap', gap: '4rpx', marginTop: '16rpx' }}>
                {m.tags.map((t) => (
                  <View key={t} style={{ padding: '4rpx 14rpx', borderRadius: '999rpx', background: 'var(--brand-soft)', color: 'var(--brand)', fontSize: '22rpx' }}>
                    <Text>#{t}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        )
      })}
    </View>
  )
}
