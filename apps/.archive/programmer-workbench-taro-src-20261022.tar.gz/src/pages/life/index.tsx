import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo } from 'react'
import { useReadingStore } from '@/stores/reading-store'
import { useFitnessStore } from '@/stores/fitness-store'
import { useMoodStore } from '@/stores/mood-store'
import { useScheduleStore } from '@/stores/schedule-store'
import { formatYMD, weekRange } from '@/utils/date'

const GREETINGS = [
  { h: 5,  greet: '凌晨好,夜猫子 ✨' },
  { h: 9,  greet: '早安!喝杯咖啡 ☕' },
  { h: 12, greet: '午间好,记得吃饭 🍱' },
  { h: 14, greet: '下午好,动起来 🍵' },
  { h: 18, greet: '傍晚好,准备收工 🌇' },
  { h: 22, greet: '夜深了,早点休息 🌙' }
]
function greeting() {
  const h = new Date().getHours()
  for (const g of GREETINGS) if (h < g.h) return g.greet
  return '夜深了,早点休息 🌙'
}

export default function LifeIndex() {
  const reading = useReadingStore((s) => s.list)
  const fitness = useFitnessStore((s) => s.records)
  const moodEntries = useMoodStore((s) => s.entries)
  const schedule = useScheduleStore((s) => s.events)

  const stats = useMemo(() => {
    const today = formatYMD(new Date())
    const { start, end } = weekRange()
    const readingCount = reading.filter((r) => r.status === 'reading').length
    const finishedCount = reading.filter((r) => r.status === 'finished').length
    const thisWeek = fitness.filter((r) => r.date >= start && r.date <= end)
    const fitnessDays = new Set(thisWeek.map((r) => r.date)).size
    const todayMood = moodEntries.find((m) => m.date === today)
    const upcomingEvents = schedule.filter((e) => !e.done && new Date(e.startAt).getTime() >= Date.now()).length
    return { readingCount, finishedCount, fitnessDays, todayMood, upcomingEvents }
  }, [reading, fitness, moodEntries, schedule])

  const goto = (url: string) => Taro.navigateTo({ url })

  return (
    <View className='page-container'>
      <View style={{
        borderRadius: '32rpx', padding: '32rpx 24rpx', marginBottom: '24rpx',
        background: 'linear-gradient(135deg, #f59e0b 0%, #ef4444 50%, #ec4899 100%)',
        color: 'white', boxShadow: 'var(--shadow-md)'
      }}>
        <Text style={{ fontSize: '26rpx', opacity: 0.85 }}>{greeting()}</Text>
        <View style={{ fontSize: '40rpx', fontWeight: 700, marginTop: '4rpx' }}>生活,也是灵感来源</View>
        <Text style={{ fontSize: '26rpx', marginTop: '16rpx', lineHeight: 1.5, opacity: 0.95 }}>
          "保持好奇,记录生活。每一份坚持,都会成为未来的底气。"
        </Text>
        <Text style={{ fontSize: '22rpx', marginTop: '16rpx', opacity: 0.85 }}>{formatYMD(new Date())}</Text>
      </View>

      <View style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16rpx' }}>
        <View style={{ padding: '24rpx', background: 'var(--bg-secondary)', borderRadius: '24rpx', boxShadow: 'var(--shadow-sm)' }} onClick={() => goto('/pages/life/reading/index')}>
          <Text style={{ fontSize: '56rpx' }}>📖</Text>
          <View style={{ fontSize: '30rpx', fontWeight: 700, marginTop: '16rpx' }}>在读书</View>
          <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>好书,慢慢读</Text>
          <View style={{ marginTop: '16rpx', fontSize: '28rpx', fontWeight: 600 }}>
            {stats.readingCount}<Text style={{ fontSize: '22rpx', fontWeight: 400, color: 'var(--text-muted)', marginLeft: '4rpx' }}>本进行中</Text>
          </View>
        </View>
        <View style={{ padding: '24rpx', background: 'var(--bg-secondary)', borderRadius: '24rpx', boxShadow: 'var(--shadow-sm)' }} onClick={() => goto('/pages/life/fitness/index')}>
          <Text style={{ fontSize: '56rpx' }}>💪</Text>
          <View style={{ fontSize: '30rpx', fontWeight: 700, marginTop: '16rpx' }}>健身</View>
          <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>让代码之外的自己更强</Text>
          <View style={{ marginTop: '16rpx', fontSize: '28rpx', fontWeight: 600 }}>
            {stats.fitnessDays}/7<Text style={{ fontSize: '22rpx', fontWeight: 400, color: 'var(--text-muted)', marginLeft: '4rpx' }}>本周天数</Text>
          </View>
        </View>
        <View style={{ padding: '24rpx', background: 'var(--bg-secondary)', borderRadius: '24rpx', boxShadow: 'var(--shadow-sm)' }} onClick={() => goto('/pages/life/mood/index')}>
          <Text style={{ fontSize: '56rpx' }}>💭</Text>
          <View style={{ fontSize: '30rpx', fontWeight: 700, marginTop: '16rpx' }}>心情</View>
          <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>记录每日的情绪</Text>
          <View style={{ marginTop: '16rpx', fontSize: '28rpx', fontWeight: 600 }}>
            {stats.todayMood?.emoji ?? '—'}
            <Text style={{ fontSize: '22rpx', fontWeight: 400, color: 'var(--text-muted)', marginLeft: '4rpx' }}>{stats.todayMood ? '今日已记录' : '今日未记录'}</Text>
          </View>
        </View>
        <View style={{ padding: '24rpx', background: 'var(--bg-secondary)', borderRadius: '24rpx', boxShadow: 'var(--shadow-sm)' }} onClick={() => goto('/pages/life/schedule/index')}>
          <Text style={{ fontSize: '56rpx' }}>📅</Text>
          <View style={{ fontSize: '30rpx', fontWeight: 700, marginTop: '16rpx' }}>日程</View>
          <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>会议、提醒、生日</Text>
          <View style={{ marginTop: '16rpx', fontSize: '28rpx', fontWeight: 600 }}>
            {stats.upcomingEvents}<Text style={{ fontSize: '22rpx', fontWeight: 400, color: 'var(--text-muted)', marginLeft: '4rpx' }}>项待办</Text>
          </View>
        </View>
      </View>
    </View>
  )
}
