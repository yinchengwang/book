import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useScheduleStore } from '@/stores/schedule-store'
import { Empty } from '@/components/common/Empty'
import { formatYMDHM, humanDay } from '@/utils/date'

export default function SchedulePage() {
  const events = useScheduleStore((s) => s.events)
  const add = useScheduleStore((s) => s.add)
  const remove = useScheduleStore((s) => s.remove)
  const toggleDone = useScheduleStore((s) => s.toggleDone)
  const [showModal, setShowModal] = useState(false)
  const [m_title, setMTitle] = useState('')
  const [m_start, setMStart] = useState('')
  const [m_end, setMEnd] = useState('')
  const [m_location, setMLocation] = useState('')
  const [m_note, setMNote] = useState('')
  const [m_reminder, setMReminder] = useState(false)
  const [view, setView] = useState<'upcoming' | 'done' | 'all'>('upcoming')

  const filtered = useMemo(() => {
    const now = Date.now()
    let list = events
    if (view === 'upcoming') list = list.filter((e) => !e.done && new Date(e.startAt).getTime() >= now - 3600_000)
    else if (view === 'done') list = list.filter((e) => e.done)
    return [...list].sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime())
  }, [events, view])

  const grouped = useMemo(() => {
    const out: Record<string, typeof events> = {}
    filtered.forEach((e) => {
      const k = e.startAt.slice(0, 10)
      if (!out[k]) out[k] = []
      out[k].push(e)
    })
    return out
  }, [filtered])

  const open = () => {
    const now = new Date()
    now.setMinutes(0, 0, 0); now.setHours(now.getHours() + 1)
    setMStart(formatYMDHM(now)); setMTitle(''); setMEnd(''); setMLocation(''); setMNote(''); setMReminder(true)
    setShowModal(true)
  }
  const submit = () => {
    if (!m_title.trim()) return Taro.showToast({ title: '请输入事件名', icon: 'none' })
    if (!m_start.trim()) return Taro.showToast({ title: '请选择开始时间', icon: 'none' })
    try {
      const startAt = new Date(m_start).toISOString()
      const endAt = m_end ? new Date(m_end).toISOString() : undefined
      add({ title: m_title.trim(), startAt, endAt, location: m_location.trim() || undefined, note: m_note.trim() || undefined, reminder: m_reminder })
      setShowModal(false)
      Taro.showToast({ title: '已添加', icon: 'success' })
    } catch {
      Taro.showToast({ title: '时间格式不正确', icon: 'none' })
    }
  }
  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['删除'],
      success: (r) => { if (r.tapIndex === 0) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) }) }
    })
  }

  return (
    <View className='page-container'>
      <View style={{ display: 'flex', background: 'var(--bg-secondary)', borderRadius: '999rpx', padding: '6rpx', marginBottom: '24rpx' }}>
        {(['upcoming', 'done', 'all'] as const).map((v) => (
          <View key={v}
            style={{ flex: 1, textAlign: 'center', padding: '12rpx 0', fontSize: '26rpx', color: view === v ? 'white' : 'var(--text-secondary)', background: view === v ? 'var(--brand)' : 'transparent', borderRadius: '999rpx', fontWeight: view === v ? 600 : 400 }}
            onClick={() => setView(v)}>
            {v === 'upcoming' ? '即将到来' : v === 'done' ? '已完成' : '全部'}
          </View>
        ))}
      </View>

      {Object.entries(grouped).length === 0 && <Empty icon='📅' title='没有日程' actionText='新建日程' onAction={open} />}
      {Object.entries(grouped).map(([date, items]) => (
        <View key={date} style={{ marginBottom: '24rpx' }}>
          <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 8rpx 16rpx' }}>
            <Text style={{ fontSize: '28rpx', fontWeight: 700, color: 'var(--text-primary)' }}>{humanDay(date)}</Text>
            <Text style={{ fontSize: '22rpx', color: 'var(--text-muted)' }}>{items.length} 项</Text>
          </View>
          {items.map((e) => (
            <View key={e.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '16rpx', boxShadow: 'var(--shadow-sm)', display: 'flex', alignItems: 'center', gap: '24rpx', position: 'relative', overflow: 'hidden', opacity: e.done ? 0.55 : 1 }}
              onLongPress={() => onLongPress(e.id)}>
              <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '8rpx', background: 'var(--brand)' }} />
              <View
                style={{ width: '40rpx', height: '40rpx', borderRadius: '50%', border: '2rpx solid var(--brand)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28rpx', color: 'var(--brand)', flexShrink: 0, marginLeft: '8rpx', background: e.done ? 'var(--brand)' : 'transparent' }}
                onClick={() => toggleDone(e.id)}>
                {e.done ? <Text style={{ color: 'white' }}>✓</Text> : ''}
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={{ fontSize: '30rpx', fontWeight: 600, color: e.done ? 'var(--text-muted)' : 'var(--text-primary)', textDecoration: e.done ? 'line-through' : 'none' }}>{e.title}</Text>
                <View style={{ fontSize: '22rpx', color: 'var(--text-muted)', marginTop: '4rpx', display: 'flex', flexWrap: 'wrap', gap: '16rpx' }}>
                  <Text style={{ color: 'var(--brand)', fontWeight: 600 }}>
                    🕐 {formatYMDHM(e.startAt).slice(11)}{e.endAt && `-${formatYMDHM(e.endAt).slice(11)}`}
                  </Text>
                  {e.location && <Text>📍 {e.location}</Text>}
                  {e.reminder && <Text style={{ color: 'var(--warning)' }}>🔔</Text>}
                </View>
                {e.note && <Text style={{ fontSize: '26rpx', color: 'var(--text-secondary)', marginTop: '8rpx' }}>{e.note}</Text>}
              </View>
            </View>
          ))}
        </View>
      ))}

      <View className='fab' onClick={open}>+</View>

      {showModal && (
        <View className='modal-mask' onClick={() => setShowModal(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>新建日程</View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>事件名</Text>
              <Input value={m_title} onInput={(e) => setMTitle((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>开始时间 (YYYY-MM-DD HH:mm)</Text>
              <Input value={m_start} onInput={(e) => setMStart((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>结束(选填)</Text>
              <Input value={m_end} onInput={(e) => setMEnd((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>地点</Text>
              <Input value={m_location} onInput={(e) => setMLocation((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>备注</Text>
              <Textarea value={m_note} onInput={(e) => setMNote((e.detail as any).value)} autoHeight
                style={{ width: '100%', minHeight: '100rpx', padding: '16rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '24rpx', display: 'flex', alignItems: 'center', gap: '12rpx' }}>
              <View
                style={{ width: '40rpx', height: '40rpx', borderRadius: '8rpx', background: m_reminder ? 'var(--brand)' : 'var(--bg-tertiary)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}
                onClick={() => setMReminder(!m_reminder)}>
                {m_reminder ? '✓' : ''}
              </View>
              <Text style={{ fontSize: '26rpx', color: 'var(--text-secondary)' }}>提醒</Text>
            </View>
            <View style={{ display: 'flex', gap: '16rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowModal(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submit}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
