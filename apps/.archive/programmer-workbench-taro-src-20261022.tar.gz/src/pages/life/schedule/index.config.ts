export default definePageConfig({ navigationBarTitleText: '日程', enablePullDownRefresh: true })
