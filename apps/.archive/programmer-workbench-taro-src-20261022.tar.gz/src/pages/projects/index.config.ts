export default definePageConfig({ navigationBarTitleText: '项目作品集', enablePullDownRefresh: true })
