import { View, Text, Input, Textarea } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { useMemo, useState } from 'react'
import { useProjectsStore } from '@/stores/projects-store'
import { Empty } from '@/components/common/Empty'
import type { ProjectStatus } from '@/types'

const STATUS_LABEL: Record<ProjectStatus, { label: string; cls: string }> = {
  active: { label: '活跃', cls: 'ok' },
  wip: { label: '进行中', cls: 'warn' },
  archived: { label: '归档', cls: 'mute' }
}

export default function ProjectsPage() {
  const projects = useProjectsStore((s) => s.projects)
  const remove = useProjectsStore((s) => s.remove)
  const [showModal, setShowModal] = useState(false)
  const [m_name, setMName] = useState('')
  const [m_desc, setMDesc] = useState('')
  const [m_tech, setMTech] = useState('')
  const [m_highlights, setMHighlights] = useState('')
  const [m_repo, setMRepo] = useState('')
  const [m_demo, setMDemo] = useState('')
  const [m_status, setMStatus] = useState<ProjectStatus>('active')
  const [m_stars, setMStars] = useState(5)

  const counts = useMemo(() => ({
    total: projects.length,
    active: projects.filter((p) => p.status === 'active').length,
    wip: projects.filter((p) => p.status === 'wip').length,
    archived: projects.filter((p) => p.status === 'archived').length
  }), [projects])

  const submit = () => {
    if (!m_name.trim()) return Taro.showToast({ title: '请输入项目名', icon: 'none' })
    const tech = m_tech.split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean)
    const highlights = m_highlights.split(/\n+/).map((s) => s.trim()).filter(Boolean)
    useProjectsStore.getState().add({
      name: m_name.trim(), description: m_desc.trim(),
      techStack: tech, highlights, status: m_status, stars: m_stars,
      repoUrl: m_repo.trim() || undefined, demoUrl: m_demo.trim() || undefined
    })
    setShowModal(false)
    setMName(''); setMDesc(''); setMTech(''); setMHighlights(''); setMRepo(''); setMDemo('')
    Taro.showToast({ title: '已添加', icon: 'success' })
  }

  const onLongPress = (id: string) => {
    Taro.showActionSheet({
      itemList: ['删除'],
      success: (r) => { if (r.tapIndex === 0) Taro.showModal({ title: '删除?', success: (m) => m.confirm && remove(id) }) }
    })
  }
  const onOpen = (url?: string) => {
    if (!url) return
    Taro.setClipboardData({ data: url, success: () => Taro.showToast({ title: '链接已复制', icon: 'success' }) })
  }

  const statusStyle = (s: ProjectStatus): React.CSSProperties => ({
    fontSize: '22rpx', padding: '4rpx 14rpx', borderRadius: '999rpx',
    background: s === 'active' ? 'var(--success-soft)' : s === 'wip' ? 'var(--warning-soft)' : 'var(--bg-tertiary)',
    color: s === 'active' ? 'var(--success)' : s === 'wip' ? 'var(--warning)' : 'var(--text-muted)'
  })

  return (
    <View className='page-container'>
      <View style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #0ea5e9 100%)', color: 'white', borderRadius: '32rpx', padding: '32rpx 24rpx', marginBottom: '24rpx', boxShadow: 'var(--shadow-md)' }}>
        <Text style={{ fontSize: '40rpx', fontWeight: 700 }}>作品集 / Projects</Text>
        <View style={{ fontSize: '26rpx', marginTop: '16rpx', lineHeight: 1.5, opacity: 0.9 }}>用作品证明自己 · 持续迭代,持续输出</View>
        <View style={{ display: 'flex', gap: '24rpx', marginTop: '24rpx' }}>
          <View style={{ flex: 1, background: 'rgba(255,255,255,0.18)', borderRadius: '16rpx', padding: '16rpx' }}>
            <View style={{ fontSize: '40rpx', fontWeight: 700, lineHeight: 1.1 }}>{counts.total}</View>
            <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>项目总数</Text>
          </View>
          <View style={{ flex: 1, background: 'rgba(255,255,255,0.18)', borderRadius: '16rpx', padding: '16rpx' }}>
            <View style={{ fontSize: '40rpx', fontWeight: 700, lineHeight: 1.1 }}>{counts.active + counts.wip}</View>
            <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>活跃</Text>
          </View>
          <View style={{ flex: 1, background: 'rgba(255,255,255,0.18)', borderRadius: '16rpx', padding: '16rpx' }}>
            <View style={{ fontSize: '40rpx', fontWeight: 700, lineHeight: 1.1 }}>{counts.archived}</View>
            <Text style={{ fontSize: '22rpx', opacity: 0.9 }}>归档</Text>
          </View>
        </View>
      </View>

      {projects.length === 0 && <Empty icon='🚀' title='还没有项目' actionText='新建项目' onAction={() => setShowModal(true)} />}
      {projects.map((p) => (
        <View key={p.id} style={{ background: 'var(--bg-secondary)', borderRadius: '24rpx', padding: '24rpx', marginBottom: '24rpx', boxShadow: 'var(--shadow-sm)' }} onLongPress={() => onLongPress(p.id)}>
          <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16rpx' }}>
            <Text style={{ fontSize: '34rpx', fontWeight: 700, color: 'var(--text-primary)', flex: 1, wordBreak: 'break-all' }}>{p.name}</Text>
            <View style={statusStyle(p.status)}><Text>{STATUS_LABEL[p.status].label}</Text></View>
          </View>
          <Text style={{ fontSize: '26rpx', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '16rpx' }}>{p.description}</Text>
          <View style={{ display: 'flex', flexWrap: 'wrap', gap: '4rpx', marginBottom: '16rpx' }}>
            {p.techStack.map((t) => (
              <Text key={t} style={{ padding: '4rpx 14rpx', borderRadius: '999rpx', fontSize: '22rpx', background: 'var(--accent-soft)', color: 'var(--accent)' }}>{t}</Text>
            ))}
          </View>
          {p.highlights.length > 0 && (
            <View style={{ background: 'var(--bg-tertiary)', padding: '16rpx', borderRadius: '12rpx', marginBottom: '16rpx' }}>
              {p.highlights.map((h, i) => (
                <Text key={i} style={{ fontSize: '24rpx', color: 'var(--text-primary)', padding: '4rpx 0' }}>· {h}</Text>
              ))}
            </View>
          )}
          <View style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: 'var(--warning)', fontSize: '26rpx' }}>{'★'.repeat(p.stars)}{'☆'.repeat(5 - p.stars)}</Text>
            <View style={{ display: 'flex', gap: '16rpx' }}>
              {p.repoUrl && <View style={{ padding: '8rpx 20rpx', borderRadius: '999rpx', fontSize: '24rpx', background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }} onClick={() => onOpen(p.repoUrl)}><Text>📦 Repo</Text></View>}
              {p.demoUrl && <View style={{ padding: '8rpx 20rpx', borderRadius: '999rpx', fontSize: '24rpx', background: 'var(--brand)', color: 'white' }} onClick={() => onOpen(p.demoUrl)}><Text>🚀 Demo</Text></View>}
            </View>
          </View>
        </View>
      ))}
      <View className='fab' onClick={() => setShowModal(true)}>+</View>

      {showModal && (
        <View className='modal-mask' onClick={() => setShowModal(false)}>
          <View className='modal-sheet' onClick={(e) => e.stopPropagation()}>
            <View className='modal-title'>添加项目</View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>项目名 *</Text>
              <Input value={m_name} onInput={(e) => setMName((e.detail as any).value)}
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>简介</Text>
              <Textarea value={m_desc} onInput={(e) => setMDesc((e.detail as any).value)} autoHeight
                style={{ width: '100%', minHeight: '120rpx', padding: '16rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>技术栈 (逗号)</Text>
              <Input value={m_tech} onInput={(e) => setMTech((e.detail as any).value)} placeholder='React, TypeScript, Taro'
                style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>亮点 (每行一条)</Text>
              <Textarea value={m_highlights} onInput={(e) => setMHighlights((e.detail as any).value)} autoHeight
                style={{ width: '100%', minHeight: '120rpx', padding: '16rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
            </View>
            <View style={{ display: 'flex', gap: '16rpx', marginBottom: '16rpx' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>Repo URL</Text>
                <Input value={m_repo} onInput={(e) => setMRepo((e.detail as any).value)}
                  style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>Demo URL</Text>
                <Input value={m_demo} onInput={(e) => setMDemo((e.detail as any).value)}
                  style={{ width: '100%', height: '72rpx', padding: '0 24rpx', borderRadius: '16rpx', background: 'var(--bg-tertiary)', fontSize: '26rpx', marginTop: '4rpx', color: 'var(--text-primary)' }} />
              </View>
            </View>
            <View style={{ marginBottom: '16rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>状态</Text>
              <View style={{ display: 'flex', gap: '8rpx', marginTop: '8rpx' }}>
                {(['active', 'wip', 'archived'] as ProjectStatus[]).map((s) => (
                  <View key={s} className={`tag-row__item${m_status === s ? ' tag-row__item--active' : ''}`} onClick={() => setMStatus(s)}>{STATUS_LABEL[s].label}</View>
                ))}
              </View>
            </View>
            <View style={{ marginBottom: '24rpx' }}>
              <Text style={{ fontSize: '24rpx', color: 'var(--text-muted)' }}>自评</Text>
              <View style={{ display: 'flex', gap: '12rpx', fontSize: '40rpx', marginTop: '8rpx' }}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <Text key={n} style={{ color: n <= m_stars ? 'var(--warning)' : 'var(--text-muted)' }} onClick={() => setMStars(n)}>
                    {n <= m_stars ? '★' : '☆'}
                  </Text>
                ))}
              </View>
            </View>
            <View style={{ display: 'flex', gap: '16rpx' }}>
              <View className='detail__btn detail__btn--ghost' onClick={() => setShowModal(false)}>取消</View>
              <View className='detail__btn detail__btn--primary' onClick={submit}>保存</View>
            </View>
          </View>
        </View>
      )}
    </View>
  )
}
