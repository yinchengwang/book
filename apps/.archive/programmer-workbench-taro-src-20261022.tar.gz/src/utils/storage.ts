import Taro from '@tarojs/taro'

const PREFIX = 'devbench:'

export const Storage = {
  get<T>(key: string, defaultValue?: T): T | undefined {
    try {
      const raw = Taro.getStorageSync(PREFIX + key)
      if (raw === '' || raw === null || raw === undefined) return defaultValue
      if (typeof raw === 'string') {
        try { return JSON.parse(raw) as T } catch { return defaultValue }
      }
      return raw as T
    } catch { return defaultValue }
  },
  set<T>(key: string, value: T): void {
    try { Taro.setStorageSync(PREFIX + key, value as any) }
    catch (err) { console.warn('[Storage.set] failed', key, err) }
  },
  remove(key: string): void {
    try { Taro.removeStorageSync(PREFIX + key) }
    catch (err) { console.warn('[Storage.remove] failed', err) }
  },
  clearAll(): void {
    try {
      const info = Taro.getStorageInfoSync()
      info.keys.filter((k) => k.startsWith(PREFIX)).forEach((k) => Taro.removeStorageSync(k))
    } catch (err) { console.warn('[Storage.clearAll] failed', err) }
  },
  exportAll(): string {
    const info = Taro.getStorageInfoSync()
    const dump: Record<string, unknown> = {}
    info.keys.forEach((k) => {
      if (k.startsWith(PREFIX)) {
        const raw = Taro.getStorageSync(k)
        if (raw !== '' && raw !== null) dump[k.replace(PREFIX, '')] = raw
      }
    })
    return JSON.stringify({ exportedAt: new Date().toISOString(), version: 1, data: dump }, null, 2)
  },
  importAll(json: string, mode: 'merge' | 'overwrite' = 'merge'): { ok: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(json)
      const data = parsed?.data
      if (!data || typeof data !== 'object') return { ok: false, count: 0, error: '备份文件格式不正确' }
      let count = 0
      Object.keys(data).forEach((k) => {
        if (mode === 'overwrite') {
          Taro.setStorageSync(PREFIX + k, data[k] as any)
        } else if (Taro.getStorageSync(PREFIX + k) === '' || Taro.getStorageSync(PREFIX + k) === null) {
          Taro.setStorageSync(PREFIX + k, data[k] as any)
        }
        count += 1
      })
      return { ok: true, count }
    } catch (err: any) {
      return { ok: false, count: 0, error: err?.message ?? String(err) }
    }
  }
}

export const StorageKeys = {
  Todos: 'todos',
  TechNotes: 'tech_notes',
  Snippets: 'snippets',
  Interview: 'interview_questions',
  Resources: 'tech_resources',
  Reading: 'reading',
  Fitness: 'fitness',
  Mood: 'mood',
  Schedule: 'schedule',
  Projects: 'projects',
  Insights: 'insights',
  Settings: 'settings'
} as const
