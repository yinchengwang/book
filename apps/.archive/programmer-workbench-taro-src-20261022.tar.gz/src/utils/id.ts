import type { ID } from '@/types'

export function genId(): ID {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
}
