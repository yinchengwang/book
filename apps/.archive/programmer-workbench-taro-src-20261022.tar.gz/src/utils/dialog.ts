import Taro from '@tarojs/taro'

/**
 * 带输入框的模态框。
 *
 * Taro 3.6 的 `showModal` 类型定义里缺少 `editable` / `placeholderText` /
 * 返回值 `content` 这几个字段(它们是微信原生 `wx.showModal` 的能力,
 * 运行时完全支持,只是 Taro 的 .d.ts 没同步),这里统一做一次类型收敛。
 */

export interface PromptOption {
  title: string
  content?: string
  placeholderText?: string
  confirmText?: string
  cancelText?: string
}

export function showPrompt(opt: PromptOption): Promise<string | null> {
  return new Promise((resolve) => {
    Taro.showModal({
      title: opt.title,
      content: opt.content,
      editable: true,
      placeholderText: opt.placeholderText,
      confirmText: opt.confirmText,
      cancelText: opt.cancelText,
      success: (res) => {
        resolve(res.confirm ? (res as any).content ?? '' : null)
      },
      fail: () => resolve(null)
    } as any)
  })
}

/** 普通确认框,返回用户是否点了「确定」 */
export function showConfirm(opt: { title: string; content?: string }): Promise<boolean> {
  return new Promise((resolve) => {
    Taro.showModal({
      title: opt.title,
      content: opt.content,
      success: (res) => resolve(!!res.confirm),
      fail: () => resolve(false)
    })
  })
}

/** 纯信息弹窗 */
export function showAlert(title: string, content: string) {
  Taro.showModal({ title, content, showCancel: false })
}