export function todayStr(): string { return formatYMD(new Date()) }

export function formatYMD(d: Date | string | number): string {
  const date = new Date(d)
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function formatYMDHM(d: Date | string | number): string {
  const date = new Date(d)
  return `${formatYMD(date)} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

export function formatRelative(iso?: string): string {
  if (!iso) return ''
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
  if (diff < 60) return '刚刚'
  if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} 天前`
  return formatYMD(iso)
}

export function weekRange(base: Date = new Date()): { start: string; end: string } {
  const d = new Date(base)
  const day = d.getDay() === 0 ? 7 : d.getDay()
  const monday = new Date(d)
  monday.setDate(d.getDate() - (day - 1))
  monday.setHours(0, 0, 0, 0)
  const sunday = new Date(monday)
  sunday.setDate(monday.getDate() + 6)
  return { start: formatYMD(monday), end: formatYMD(sunday) }
}

export function daysAgo(n: number, base: Date = new Date()): string {
  const d = new Date(base)
  d.setDate(d.getDate() - n)
  return formatYMD(d)
}

export function dateListBetween(start: string, end: string): string[] {
  const out: string[] = []
  const cursor = new Date(start)
  const e = new Date(end)
  while (cursor <= e) {
    out.push(formatYMD(cursor))
    cursor.setDate(cursor.getDate() + 1)
  }
  return out
}

export function humanDay(iso: string): string {
  const today = todayStr()
  if (iso === today) return '今天'
  if (iso === daysAgo(1)) return '昨天'
  const d = new Date(iso)
  const week = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()]
  return `${iso} 周${week}`
}
