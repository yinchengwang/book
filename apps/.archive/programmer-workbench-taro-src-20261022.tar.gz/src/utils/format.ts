export function bytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0; let v = n
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1 }
  return `${v.toFixed(v < 10 && i > 0 ? 2 : 0)} ${units[i]}`
}

export function duration(min: number): string {
  if (!Number.isFinite(min) || min < 0) return '0 分钟'
  const h = Math.floor(min / 60)
  const m = min % 60
  if (h === 0) return `${m} 分钟`
  if (m === 0) return `${h} 小时`
  return `${h} 小时 ${m} 分钟`
}

export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n))
}

export function percent(done: number, total: number): number {
  if (!total) return 0
  return clamp(Math.round((done / total) * 100), 0, 100)
}

export function truncate(str: string, n: number): string {
  if (!str) return ''
  return str.length > n ? `${str.slice(0, n)}…` : str
}
