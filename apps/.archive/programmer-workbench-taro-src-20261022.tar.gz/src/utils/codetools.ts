// 工具箱核心 - 所有纯函数,h5/小程序两端都能跑

// Base64 (UTF-8 安全)
export function base64Encode(s: string): string {
  if (typeof btoa !== 'undefined') return btoa(unescape(encodeURIComponent(s)))
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const Buf = (globalThis as any).Buffer
  if (Buf) return Buf.from(unescape(encodeURIComponent(s)), 'utf-8').toString('base64')
  throw new Error('当前环境不支持 Base64')
}
export function base64Decode(s: string): string {
  if (typeof atob !== 'undefined') {
    try { return decodeURIComponent(escape(atob(s))) } catch { return atob(s) }
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const Buf = (globalThis as any).Buffer
  if (Buf) return Buf.from(s, 'base64').toString('utf-8')
  throw new Error('当前环境不支持 Base64')
}

// URL 编码
export const urlEncode = (s: string) => encodeURIComponent(s)
export const urlDecode = (s: string) => { try { return decodeURIComponent(s) } catch { return s } }

// JSON 转换
export type JsonMode = 'beautify' | 'minify' | 'escape' | 'unescape'
export function jsonTransform(input: string, mode: JsonMode, indent = 2): string {
  if (!input.trim()) return ''
  switch (mode) {
    case 'beautify': return JSON.stringify(JSON.parse(input), null, indent)
    case 'minify':   return JSON.stringify(JSON.parse(input))
    case 'escape':   return JSON.stringify(input)
    case 'unescape': return JSON.parse(input) as string
  }
}

// 时间戳
export const tsNow = (unit: 'ms' | 's' = 'ms') =>
  unit === 'ms' ? Date.now() : Math.floor(Date.now() / 1000)

export function tsToDate(input: string | number): Date {
  const n = typeof input === 'string' ? parseInt(input, 10) : input
  return new Date(n < 1e12 ? n * 1000 : n)
}
export function dateToTs(input: string, unit: 'ms' | 's' = 'ms'): number {
  const ms = new Date(input).getTime()
  return unit === 'ms' ? ms : Math.floor(ms / 1000)
}
export function fmtDate(input: string | number | Date, pattern = 'YYYY-MM-DD HH:mm:ss'): string {
  const d = new Date(input)
  const pad = (n: number) => String(n).padStart(2, '0')
  return pattern
    .replace('YYYY', String(d.getFullYear()))
    .replace('MM', pad(d.getMonth() + 1))
    .replace('DD', pad(d.getDate()))
    .replace('HH', pad(d.getHours()))
    .replace('mm', pad(d.getMinutes()))
    .replace('ss', pad(d.getSeconds()))
}

// UUID / 随机
export function uuid(): string {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c: any = (globalThis as any).crypto
  if (c?.randomUUID) return c.randomUUID() as string
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

const CHARSETS: Record<string, string> = {
  lower: 'abcdefghijklmnopqrstuvwxyz',
  upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  digit: '0123456789',
  alphanumeric: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
  strong: '!@#$%^&*()-_=+[]{}<>?,.'
}
export function randomString(len: number, charset: keyof typeof CHARSETS | 'alphanumeric' = 'alphanumeric'): string {
  const pool = charset === 'strong'
    ? CHARSETS.alphanumeric + CHARSETS.strong
    : CHARSETS[charset] ?? CHARSETS.alphanumeric
  let s = ''
  for (let i = 0; i < len; i += 1) s += pool[Math.floor(Math.random() * pool.length)]
  return s
}

// 颜色
export interface RGB { r: number; g: number; b: number; a?: number }
export function hexToRgb(hex: string): RGB | null {
  let h = hex.trim().replace('#', '')
  if (h.length === 3) h = h.split('').map((c) => c + c).join('')
  if (h.length !== 6 && h.length !== 8) return null
  const r = parseInt(h.slice(0, 2), 16)
  const g = parseInt(h.slice(2, 4), 16)
  const b = parseInt(h.slice(4, 6), 16)
  if ([r, g, b].some(Number.isNaN)) return null
  const out: RGB = { r, g, b }
  if (h.length === 8) out.a = parseInt(h.slice(6, 8), 16) / 255
  return out
}
export function rgbToHex(rgb: RGB): string {
  const to2 = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0')
  let hex = `#${to2(rgb.r)}${to2(rgb.g)}${to2(rgb.b)}`
  if (rgb.a !== undefined) hex += to2(rgb.a * 255)
  return hex
}

// 正则
export interface RegexResult {
  matched: boolean
  /** 命中次数(全局模式下有效) */
  matchCount: number
  /** 首次匹配的捕获组 */
  groups: Record<string, string | undefined>
  groupsArr: string[]
  error?: string
  highlighted: { value: string; hit: boolean }[]
}
export function testRegex(pattern: string, input: string, flags = 'g'): RegexResult {
  const highlighted: RegexResult['highlighted'] = []
  if (!pattern) {
    highlighted.push({ value: input, hit: false })
    return { matched: false, matchCount: 0, groups: {}, groupsArr: [], highlighted }
  }
  let re: RegExp
  try { re = new RegExp(pattern, flags) }
  catch (err: any) {
    highlighted.push({ value: input, hit: false })
    return { matched: false, matchCount: 0, groups: {}, groupsArr: [], highlighted, error: err?.message ?? String(err) }
  }
  let matched = false
  let matchCount = 0
  let firstMatch: RegExpExecArray | null = null
  if (flags.includes('g')) {
    let cursor = 0
    while (cursor < input.length) {
      re.lastIndex = cursor
      const exec = re.exec(input)
      if (!exec) break
      matched = true
      matchCount += 1
      if (!firstMatch) firstMatch = exec
      if (exec.index === re.lastIndex) re.lastIndex += 1
      const start = exec.index, end = start + exec[0].length
      if (start > cursor) highlighted.push({ value: input.slice(cursor, start), hit: false })
      highlighted.push({ value: input.slice(start, end), hit: true })
      cursor = end
    }
    if (cursor < input.length) highlighted.push({ value: input.slice(cursor), hit: false })
  } else {
    const exec = re.exec(input)
    matched = !!exec
    if (exec) {
      matchCount = 1
      firstMatch = exec
      const start = exec.index, end = start + exec[0].length
      if (start > 0) highlighted.push({ value: input.slice(0, start), hit: false })
      highlighted.push({ value: input.slice(start, end), hit: true })
      if (end < input.length) highlighted.push({ value: input.slice(end), hit: false })
    } else {
      highlighted.push({ value: input, hit: false })
    }
  }
  return {
    matched,
    matchCount,
    groups: (firstMatch?.groups ?? {}) as Record<string, string | undefined>,
    groupsArr: firstMatch ? Array.from(firstMatch).slice(1) as unknown as string[] : [],
    highlighted
  }
}

// 简易 Hash
export function djb2(s: string): string {
  let h = 5381
  for (let i = 0; i < s.length; i += 1) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0
  return h.toString(16).padStart(8, '0')
}

const CRC_TABLE = (() => {
  const t: number[] = []
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c >>> 0
  }
  return t
})()
export function crc32(s: string): string {
  let c = 0xffffffff
  for (let i = 0; i < s.length; i += 1) c = CRC_TABLE[(c ^ s.charCodeAt(i)) & 0xff] ^ (c >>> 8)
  return ((c ^ 0xffffffff) >>> 0).toString(16).padStart(8, '0')
}

// LCS Diff
export type DiffOp = { type: 'eq' | 'add' | 'del'; text: string }
export function diffText(a: string, b: string): DiffOp[] {
  const m = a.length, n = b.length
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0))
  for (let i = m - 1; i >= 0; i -= 1) {
    for (let j = n - 1; j >= 0; j -= 1) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1])
    }
  }
  const out: DiffOp[] = []
  let i = 0, j = 0
  while (i < m && j < n) {
    if (a[i] === b[j]) {
      const buf: string[] = []
      while (i < m && j < n && a[i] === b[j]) { buf.push(a[i]); i += 1; j += 1 }
      out.push({ type: 'eq', text: buf.join('') })
    } else if (dp[i + 1][j] >= dp[i][j + 1]) { out.push({ type: 'del', text: a[i] }); i += 1 }
    else { out.push({ type: 'add', text: b[j] }); j += 1 }
  }
  if (i < m) out.push({ type: 'del', text: a.slice(i) })
  if (j < n) out.push({ type: 'add', text: b.slice(j) })
  return out
}

// Cron (5 段,带合法性校验和未来触发预测)
const CRON_FIELDS = [
  { min: 0, max: 59 },
  { min: 0, max: 23 },
  { min: 1, max: 31 },
  { min: 1, max: 12 },
  { min: 0, max: 6 }
] as const
export interface CronPreview { ok: boolean; description?: string; nextRuns?: string[]; error?: string }

function tokenValid(t: string, min: number, max: number): boolean {
  return t.split(',').every((tk) => {
    if (tk === '*') return true
    const stepMatch = tk.match(/^(.+)\/(\d+)$/)
    if (stepMatch) {
      const [, range, step] = stepMatch
      if (parseInt(step, 10) < 1) return false
      if (range === '*') return true
      const segs = range.split('-').map(Number)
      if (segs.length === 1) return segs[0] >= min && segs[0] <= max
      if (segs.length === 2) return segs[0] >= min && segs[1] <= max && segs[0] <= segs[1]
      return false
    }
    const segs = tk.split('-').map(Number)
    if (segs.length === 1) return segs[0] >= min && segs[0] <= max
    if (segs.length === 2) return segs[0] >= min && segs[1] <= max && segs[0] <= segs[1]
    return false
  })
}
function matchToken(t: string, value: number): boolean {
  return t.split(',').some((tk) => {
    if (tk === '*') return true
    const stepMatch = tk.match(/^(.+)\/(\d+)$/)
    if (stepMatch) {
      const [, range, step] = stepMatch
      const sN = parseInt(step, 10)
      if (range === '*') return value % sN === 0
      if (range.includes('-')) {
        const [s, e] = range.split('-').map(Number)
        const inRange = value >= s && value <= e
        const offset = (value - s) % sN
        return inRange && offset === 0
      }
    }
    if (tk.includes('-')) {
      const [s, e] = tk.split('-').map(Number)
      return value >= s && value <= e
    }
    return value === parseInt(tk, 10)
  })
}

export function describeCron(expr: string): CronPreview {
  const parts = expr.trim().split(/\s+/)
  if (parts.length !== 5) return { ok: false, error: 'cron 需要 5 段:分 时 日 月 周' }
  for (let i = 0; i < 5; i += 1) {
    if (!tokenValid(parts[i], CRON_FIELDS[i].min, CRON_FIELDS[i].max))
      return { ok: false, error: `第 ${i + 1} 段格式或范围不正确` }
  }
  const nextRuns: string[] = []
  const start = new Date()
  let cursor = new Date(Math.floor((start.getTime() + 60_000) / 60_000) * 60_000)
  let safety = 0
  while (nextRuns.length < 5 && safety < 60_000) {
    safety += 1
    if (matchToken(parts[0], cursor.getMinutes())
      && matchToken(parts[1], cursor.getHours())
      && matchToken(parts[2], cursor.getDate())
      && matchToken(parts[3], cursor.getMonth() + 1)
      && matchToken(parts[4], cursor.getDay())) {
      nextRuns.push(fmtDate(cursor))
      cursor = new Date(cursor.getTime() + 60_000)
    } else {
      cursor = new Date(cursor.getTime() + 60_000)
    }
  }
  return { ok: true, description: parts.join(' '), nextRuns }
}

// 简易 Markdown -> HTML(极简实现,够笔记预览)
export function md2html(md: string): string {
  const escape = (s: string) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c] ?? c))
  let html = escape(md)
  html = html.replace(/```([\s\S]*?)```/g, (_, c) => `<pre class="md-code"><code>${c}</code></pre>`)
  html = html.replace(/`([^`]+)`/g, '<code class="md-inline-code">$1</code>')
  html = html.replace(/^###### (.*)$/gm, '<h6>$1</h6>')
  html = html.replace(/^##### (.*)$/gm, '<h5>$1</h5>')
  html = html.replace(/^#### (.*)$/gm, '<h4>$1</h4>')
  html = html.replace(/^### (.*)$/gm, '<h3>$1</h3>')
  html = html.replace(/^## (.*)$/gm, '<h2>$1</h2>')
  html = html.replace(/^# (.*)$/gm, '<h1>$1</h1>')
  html = html.replace(/^>\s?(.*)$/gm, '<blockquote>$1</blockquote>')
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>')
  html = html.replace(/~~(.+?)~~/g, '<del>$1</del>')
  html = html.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>')
  html = html.split(/\n\n+/).map((p) => (p.startsWith('<') ? p : `<p>${p}</p>`)).join('\n')
  return html
}
