import { View, Text } from '@tarojs/components'

interface Props {
  icon?: string
  title?: string
  desc?: string
  actionText?: string
  onAction?: () => void
}

export function Empty({ icon = '📭', title = '空空如也', desc, actionText, onAction }: Props) {
  return (
    <View className='db-empty'>
      <View className='db-empty__icon'>{icon}</View>
      <Text className='db-empty__title'>{title}</Text>
      {desc && <Text className='db-empty__desc'>{desc}</Text>}
      {actionText && (
        <View className='db-empty__action' onClick={onAction}>
          <Text>{actionText}</Text>
        </View>
      )}
    </View>
  )
}
