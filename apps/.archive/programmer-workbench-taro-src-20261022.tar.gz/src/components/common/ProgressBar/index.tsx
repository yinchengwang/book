import { View, Text } from '@tarojs/components'
import classNames from 'classnames'
import { clamp } from '@/utils/format'

interface Props {
  percent: number
  color?: string
  size?: 'thin' | 'normal' | 'thick'
  showText?: boolean
  className?: string
}

export function ProgressBar({ percent, color = 'var(--brand)', size = 'normal', showText, className }: Props) {
  const p = clamp(percent, 0, 100)
  return (
    <View className={classNames('db-progress', {
      'db-progress--thin': size === 'thin',
      'db-progress--thick': size === 'thick'
    }, className)}>
      <View className='db-progress__track'>
        <View className='db-progress__fill' style={{ width: `${p}%`, background: color }} />
      </View>
      {showText && <Text className='db-progress__text'>{p}%</Text>}
    </View>
  )
}
