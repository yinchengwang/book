import { View } from '@tarojs/components'
import classNames from 'classnames'

interface Props {
  className?: string
  variant?: 'plain' | 'elevated' | 'gradient'
  onClick?: () => void
  children?: React.ReactNode
  style?: React.CSSProperties
}

export function Card({ className, variant = 'plain', onClick, children, style }: Props) {
  return (
    <View
      className={classNames('db-card', {
        'db-card--tap': !!onClick,
        'db-card--elevated': variant === 'elevated',
        'db-card--gradient': variant === 'gradient'
      }, className)}
      onClick={onClick}
      style={style}
    >
      {children}
    </View>
  )
}
