import { View, Text } from '@tarojs/components'
import classNames from 'classnames'

interface Props {
  color?: string
  bg?: string
  text?: string
  ghost?: boolean
  className?: string
  children?: React.ReactNode
}

export function Tag({ color = '#64748b', bg, text, ghost, children, className }: Props) {
  const style = ghost
    ? { color, borderColor: color }
    : { color: text ?? '#fff', background: bg || color }
  return (
    <View className={classNames('db-tag', ghost && 'db-tag--ghost', className)} style={style}>
      {typeof children === 'string' ? <Text>{children}</Text> : children}
    </View>
  )
}
