import { View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'

interface Props {
  title?: string
  showBack?: boolean
  leftSlot?: React.ReactNode
  rightSlot?: React.ReactNode
  onBack?: () => void
}

export function Header({ title, showBack = true, leftSlot, rightSlot, onBack }: Props) {
  const handleBack = () => {
    if (onBack) return onBack()
    if (Taro.getCurrentPages().length > 1) Taro.navigateBack({ delta: 1 })
  }
  return (
    <View className='db-header'>
      <View className='db-header__left'>
        {showBack ? (
          <View className='db-header__icon' onClick={handleBack}>
            <Text className='db-header__back-icon'>‹</Text>
          </View>
        ) : leftSlot}
      </View>
      <View className='db-header__title'>{title}</View>
      <View className='db-header__right'>{rightSlot}</View>
    </View>
  )
}
