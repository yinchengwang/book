const path = require('path')

module.exports = {
  projectName: 'programmer-workbench',
  date: '2026-10-19',
  framework: 'react',
  design: '750',
  sourceRoot: 'src',
  outputRoot: 'dist',

  // 项目级 ts 别名 (与 tsconfig.json / babel 一致)
  alias: {
    '@/components': path.join(__dirname, '..', 'src/components'),
    '@/pages':      path.join(__dirname, '..', 'src/pages'),
    '@/stores':     path.join(__dirname, '..', 'src/stores'),
    '@/utils':      path.join(__dirname, '..', 'src/utils'),
    '@/types':      path.join(__dirname, '..', 'src/types'),
    '@/styles':     path.join(__dirname, '..', 'src/styles')
  },

  // 复制工程内其他小程序的成功最小配置
  plugins: [
    '@tarojs/plugin-framework-react'
  ],

  // 同时支持 weapp + h5,按需加载目标平台插件
  defineConstants: {},

  copy: {
    patterns: [],
    options: {}
  },

  // 微信小程序特有
  mini: {},
  weapp: {
    appid: 'touristappid'
  },

  // H5 特有
  h5: {
    publicPath: '/',
    staticDirectory: 'static',
    output: { filename: 'js/[name].[hash:8].js' },
    miniCssExtractPluginOption: { ignoreOrder: true, filename: 'css/[name].[hash].css' },
    postcss: { autoprefixer: { enable: true } },
    devServer: { port: 10086, host: '0.0.0.0' }
  }
}
